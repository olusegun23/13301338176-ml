package ml.dataservices.internal.background.snapshot;

import android.util.Log;

/**
 * Created by haijunz on 17-11-14.
 */

public class PowerkeyFreeState extends State {
    private static String TAG = PowerkeyFreeState.class.getSimpleName();

     PowerkeyFreeState(int current) {
        last = current;
    }

    public void doAction(PowerKeyContext context,int current) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + "  current is :" + current);

        if (current > this.last) {
            context.setState(new PowerkeyPressState(current));
        }



    }


    public String toString() {

        return ("PowerKey:Free");
    }



}