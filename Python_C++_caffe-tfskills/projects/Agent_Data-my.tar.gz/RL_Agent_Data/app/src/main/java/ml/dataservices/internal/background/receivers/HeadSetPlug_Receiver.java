package ml.dataservices.internal.background.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.utils.Globals;

public class HeadSetPlug_Receiver extends BroadcastReceiver {

    private static  String TAG = HeadSetPlug_Receiver.class.getSimpleName();

    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        Globals g = Globals.getInstance();
        g.metaContext.mHeadSetPlug.mCreateTime= Calendar.getInstance();

        if(intent.getAction().equals(Intent.ACTION_HEADSET_PLUG)) {
            int state = intent.getIntExtra("state", -1);
            switch(state) {
                case(0):
                    Log.d(TAG, "Headset unplugged");
                    g.metaContext.mHeadSetPlug.mData="HeadSetPlug: NO";

                    break;
                case(1):
                    Log.d(TAG, "Headset plugged");
                    g.metaContext.mHeadSetPlug.mData="HeadSetPlug: YES";
                    break;
                default:
                    Log.d(TAG, "Error");
            }
        }


    }
}
