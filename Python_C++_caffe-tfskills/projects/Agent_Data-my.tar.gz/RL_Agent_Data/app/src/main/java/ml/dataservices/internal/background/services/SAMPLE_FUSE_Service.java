package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.IBinder;
import android.util.Log;


import static java.lang.Thread.sleep;
import ml.dataservices.internal.datastructure.MetaContext;
import ml.dataservices.internal.utils.Globals;
import ml.dataservices.internal.background.snapshot.PowerKey;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class SAMPLE_FUSE_Service extends Service {


    private static  String TAG = SAMPLE_FUSE_Service.class.getSimpleName();
    Globals g ;
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    public SAMPLE_FUSE_Service() {

    }

    @Override
    public void onCreate() {

        // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+".."+ b);
       // https://developer.android.com/reference/android/app/ActivityManager.RecentTaskInfo.html

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        // g = (Globals)getApplication();

        g=Globals.getInstance();
        g.metaContext= MetaContext.getInstance();

       /* UserManager userManager = (UserManager)getSystemService(Context.USER_SERVICE);
        UserHandle me = android.os.Process.myUserHandle();
        long serialNumber = userManager.getSerialNumberForUser(me);
     */

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);
               //Creating new thread for my service
        //Always write your long running tasks in a separate thread, to avoid ANR
        new Thread(new Runnable() {

            @Override
            public void run() {

//               HardwarePropertiesManager hardware = (HardwarePropertiesManager) getSystemService(Context.HARDWARE_PROPERTIES_SERVICE);
                 try {
                    while (g.isRunning) {

                       sleep(g.mServicesSleepTime);
//for No MTP crash     PowerKey.snapshot();

                       // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--cpuTemperature=="+g.metaContext.mCpuItem.mCreateTime.getTimeInMillis());

                        //                 float[] cpuTemperature = hardware.getDeviceTemperatures(HardwarePropertiesManager.DEVICE_TEMPERATURE_CPU, HardwarePropertiesManager.TEMPERATURE_CURRENT);
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);

                        g.metaContext.mDumpTime=Calendar.getInstance();
                        long currentTime = System.currentTimeMillis();
                        Log.d(TAG," "+g.metaContext);

                        appendLog(""+g.metaContext);

        }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

                return Service.START_STICKY;
            //return mStartMode;

    }


    public void appendLog(String text) {
     File root = android.os.Environment.getExternalStorageDirectory();

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        String formatted = format1.format(cal.getTime());
        System.out.println(formatted);
         // Output "2012-09-26
        File logFile = new File(root.getAbsolutePath() + "/"+ "State-log-"+formatted+".csv");
        Log.e(TAG, "log-log: "+logFile);

        if (!logFile.exists()) {
            try {
                logFile.createNewFile();
            }
            catch (IOException e) {
                Log.e(TAG, e.getMessage(), e);
            }
        }
        try {
            //BufferedWriter for performance, true to set append to file flag
            BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true));
            buf.append(text);
            buf.newLine();
            buf.close();
        } catch (IOException e) {

            Log.e(TAG, e.getMessage(), e);
        }
    }

    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {


        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }





}



