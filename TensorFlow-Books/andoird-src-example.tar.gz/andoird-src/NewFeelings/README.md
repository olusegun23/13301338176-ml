New Feelings -- An album application for Android && use tensorflow to classify images

[history：Album-Category](https://github.com/gaohuangzhang/Album-Category)
