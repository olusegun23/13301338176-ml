package ml.dataservices.internal.background;

import android.app.Service;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.datastructure.MetaContext;

import static java.lang.Thread.sleep;

public class Resource_Service extends Service {

    private MetaContext one = MetaContext.getInstance();

    public Resource_Service() {
    }

    private static  String TAG = "";

    private boolean isRunning  = false;

    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    @Override
    public void onCreate() {



        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);





    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);

        isRunning = true;

        //Creating new thread for my service
        //Always write your long running tasks in a separate thread, to avoid ANR
        new Thread(new Runnable() {


            String daysArray[] = {"Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday", "Saturday"};

            @Override
            public void run() {
                try {
                    while (isRunning) {
                        sleep(1000);

                        int hour = Calendar.getInstance().get(Calendar.HOUR);
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--hour--"+hour);

                        int day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--day--"+daysArray[day]);

                        long currentTime = System.currentTimeMillis();
                        // get usage stats for the last 10 seconds







                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();



        return Service.START_STICKY;
        //return mStartMode;




    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {

        isRunning = false;

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

}



