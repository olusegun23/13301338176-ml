#include <stdio.h>
#include<array>
template <typename T, int N>
struct my_array {
T data[N];
};


int main(void)
{
	printf("Hello world!\n");
        my_array<int,10> a;
	return 0;
}
