/*==============================================================================
 Copyright (c) 2015 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/

#ifndef IO_TEST_SUITE_H_
#define IO_TEST_SUITE_H_


/**
 * @brief Runs all the io tests.
 * 
 * @par
 * Tests that are run (in order)
 * 1) dspal_tester_spi_test
 * 2) dspal_tester_serial_test
 * 3) dspal_tester_i2c_test
 * 4) dspal_tester_test_gpio_open_close
 * 5) dspal_tester_test_gpio_ioctl_io
 * 6) dspal_tester_test_gpio_read_write
 * 7) dspal_tester_test_gpio_int
 * 8) dspal_tester_test_posix_file_open
 * 9) dspal_tester_test_posix_file_close
 * 10) dspal_tester_test_posix_file_read
 * 11) dspal_tester_test_posix_file_write
 * 12) dspal_tester_test_posix_file_ioctl
 *
 * @return
 * TEST_PASS ------ All tests passed
 * TEST_FAIL ------ One or more tests failed
*/
int run_io_test_suite(void);

#endif /* IO_TEST_SUITE_H_ */
