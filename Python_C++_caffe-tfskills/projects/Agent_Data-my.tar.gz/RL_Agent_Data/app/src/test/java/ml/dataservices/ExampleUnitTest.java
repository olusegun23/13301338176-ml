package ml.dataservices;

import org.junit.Test;
import java.util.concurrent.*;
import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */

// the producer puts strings on the queue
class Producer implements Runnable {

    ConcurrentLinkedQueue<String> queue;
    Producer(ConcurrentLinkedQueue<String> queue){
        this.queue = queue;
    }
    public void run() {
        System.out.println("Producer Started");
        try {
            for (int i = 1; i < 10; i++) {
                queue.add("String" + i);
                System.out.println("Added: String" + i);
                Thread.currentThread().sleep(200);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

// the consumer removes strings from the queue
class Consumer implements Runnable {

    ConcurrentLinkedQueue<String> queue;
    Consumer(ConcurrentLinkedQueue<String> queue){
        this.queue = queue;
    }
    public void run() {
        String str;
        System.out.println("Consumer Started");
        for (int x = 0; x < 10; x++) {
            while ((str = queue.poll()) != null) {
                System.out.println("Removed: " + str);
            }
            try {
                Thread.currentThread().sleep(500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}



public class ExampleUnitTest {
    @Test
    public void ConcurrentLinkedQueue_isCorrect() throws Exception {
        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<String>();
        Thread producer = new Thread(new Producer(queue));
        Thread consumer = new Thread(new Consumer(queue));
        producer.start();
        consumer.start();
        while (true) {
            try {
                producer.join();
                consumer.join();
                break;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }


    }


    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }







}




