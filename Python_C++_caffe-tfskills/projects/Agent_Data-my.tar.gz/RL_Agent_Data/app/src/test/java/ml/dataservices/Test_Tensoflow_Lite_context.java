package ml.dataservices;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.Assert.assertEquals;

/**
 * Created by haijunz on 17-12-1.
 */

public class Test_Tensoflow_Lite_context {


    @Test
    public void parse_DPC() throws Exception {

        String s = "llllcomputerllllllllll";

        Matcher m = Pattern.compile("computer").matcher(s);
        if (m.find()) {

            System.out.println(" Find ");

        } else {

            System.out.println(" Not Find ");

        }



    }





}



