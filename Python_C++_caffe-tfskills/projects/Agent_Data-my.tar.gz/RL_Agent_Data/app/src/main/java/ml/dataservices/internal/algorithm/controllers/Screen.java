package ml.dataservices.internal.algorithm.controllers;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.PowerManager;
import android.util.Log;

/**
 * Created by haijunz on 17-11-6.
 */

public class Screen
{
    private static final String TAG =Screen.class.getSimpleName();
    //  int defaultTurnOffTime =  Settings.System.getInt(this.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 60000);
   //Settings.System.putInt(Screen(),Settings.System.SCREEN_OFF_TIMEOUT, 1000)
     //   Settings.System.putInt(
    Context mContext;

    public Screen(Context mContext) {
        this.mContext = mContext;
    }

    public void turnOnScreen1(){
        PowerManager pm=(PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
        // pm.wakeUp(SystemClock.uptimeMillis());
        Log.i(TAG, "Screen ON " + Thread.currentThread().getStackTrace()[2]);

    }


    public void turnOffScreen1(){
        PowerManager pm=(PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
        // pm.goToSleep(SystemClock.uptimeMillis());
        Log.i(TAG, "Screen off " + Thread.currentThread().getStackTrace()[2]);


    }


    public void turnOnScreen2(){
        // turn on screen
        Log.i(TAG, "Screen ON " + Thread.currentThread().getStackTrace()[2]);
        PowerManager pm=(PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP|PowerManager.SCREEN_DIM_WAKE_LOCK, "bright");
        wl.acquire(10000);
        wl.release();

        /*  KeyguardManager km = (KeyguardManager) mContext.getSystemService(Context.KEYGUARD_SERVICE);
        if (!km.isKeyguardSecure()) {
            KeyguardManager.KeyguardLock kl = km.newKeyguardLock("unLock");
            kl.disableKeyguard();
        }*/

    }

    public void turnOffScreen2(){
        // turn off screen
        DevicePolicyManager policyManager = (DevicePolicyManager) mContext.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminReceiver = new ComponentName(mContext.getApplicationContext(),ScreenAdminReceiver.class);
        boolean admin = policyManager.isAdminActive(adminReceiver);
        if (admin) {
            Log.i(TAG, "Going to sleep now.");
            policyManager.lockNow();

        } else {
            Log.i(TAG, "Not an admin");
             }

        Log.i(TAG, "Screen off " + Thread.currentThread().getStackTrace()[2]);
    }

    public void turnOnScreen3(){
        Log.i(TAG, "Screen ON " + Thread.currentThread().getStackTrace()[2]);
        /* String myExec = "sh settings get system screen_brightnes";
                        StringBuilder result=new StringBuilder();
                        final StringBuilder append = result.append("....");
                        Process process;
                        try {
                            process = Runtime.getRuntime().exec("am start -a android.intent.action.MAIN -n com.android.settings/.Settings");
                            process = Runtime.getRuntime().exec("getprop  ro.sf.lcd_density");
                            process = Runtime.getRuntime().exec("cat /sys/class/leds/lcd-backlight/brightness");
                            process = Runtime.getRuntime().exec("cat /sys/class/power_supply/battery/current_now");
                            process.waitFor();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                            String s = reader.readLine();
                            long currentTime = System.currentTimeMillis();
                        }
                        catch(Exception e) {
                            e.printStackTrace();
                        }  */

    }

    public void turnOffScreen3(){
        // turn off screen
        Log.i(TAG, "Screen off " + Thread.currentThread().getStackTrace()[2]);

    }


}
