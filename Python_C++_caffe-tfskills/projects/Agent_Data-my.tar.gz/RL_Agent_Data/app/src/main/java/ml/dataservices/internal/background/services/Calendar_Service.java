package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import ml.dataservices.internal.background.receivers.Screen_ChangeReceiver;
import ml.dataservices.internal.utils.Globals;

import static java.lang.Thread.sleep;

public class Calendar_Service extends Service {


        private static  String TAG = Calendar_Service.class.getSimpleName();
        private Screen_ChangeReceiver mScreenReceiver;


    public Calendar_Service() {
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
            return null;
        }

    @Override
    public void onCreate() {

        }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);

        new Thread(new Runnable() {

            @Override
            public void run() {

                Globals g = Globals.getInstance();


                try {
                    while (g.isRunning) {

                            sleep(g.mServicesSleepTime);


                        /*    Cursor cursor = getContentResolver().query(
                                    Uri.parse("content://com.android.calendar/events"),
                                    new String[] { "_id" }, " _id = ? ",
                                    new String[] { cal_meeting_id }, null);





                       /* g.metaContext.mDeviceInfo.mCreateTime= Calendar.getInstance();
                        g.metaContext.mDeviceInfo.mData="LCD_Brightness:"+curBrightnessValue; */

//                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--LCD=="+curBrightnessValue);




                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }




            }
        }).start();



        return Service.START_STICKY;
        //return mStartMode;




    }




    @Override
        public void onDestroy() {
            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        }



}
