/*==============================================================================
 Copyright (c) 2015 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/

#include <dspal_version.h>
#include <HAP_farf.h>
#include "dspal_tester.h"

int dspal_tester_test_dspal_get_version_info()
{
	char *version_string[DSPAL_MAX_LEN_VERSION_INFO_STR];
	char *build_date_string[DSPAL_MAX_LEN_VERSION_INFO_STR];
	char *build_time_string[DSPAL_MAX_LEN_VERSION_INFO_STR];

	struct dspal_version_info version_info;

	dspal_get_version_info((char *)version_string, (char *)build_date_string,
			(char *)build_time_string);

    FARF(ALWAYS, "version: %s", version_string);
    FARF(ALWAYS, "build date: %s", build_date_string);
    FARF(ALWAYS, "build time: %s", build_time_string);

	dspal_get_version_info_ext(&version_info);

    FARF(ALWAYS, "version ext: %s", version_info.version_string);
    FARF(ALWAYS, "build date ext: %s", version_info.build_date);
    FARF(ALWAYS, "build time ext: %s", version_info.build_time);
	return 0;
}
