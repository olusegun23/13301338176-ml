# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 14:17:27 2017

@author: xiaoguangli
"""
import logging
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
import fasttext
import sys  
reload(sys)
#sys.setdefaultencoding('utf8')  
reload(sys)


classifier = fasttext.load_model('news_fasttext.model.bin', label_prefix='__label__')




labels_right = []
texts = []




with open("news_fasttext_test.txt") as fr:
    for line in fr:
        line = line.rstrip()
        line = line.decode('utf-8').rstrip()

        mm=line.split("\t");
        print "==line==\n"
        print line
        print "=mm[0]=\n"

        print mm[0]

        print "=mm[1]=\n"

        print mm[1];


        labels_right.append(line.split("\t")[1].replace("__label__",""))


        texts.append(line.split("\t")[0])
    #     print labels
    #     print texts
#     break
labels_predict = [e[0] for e in classifier.predict(texts)] 
# print labels_predict

text_labels = list(set(labels_right))
text_predict_labels = list(set(labels_predict))
print text_predict_labels
print text_labels

A = dict.fromkeys(text_labels,0)  
B = dict.fromkeys(text_labels,0)  
C = dict.fromkeys(text_predict_labels,0) 
for i in range(0,len(labels_right)):
    B[labels_right[i]] += 1
    C[labels_predict[i]] += 1
    if labels_right[i] == labels_predict[i]:
        A[labels_right[i]] += 1

print A 
print B
print C
for key in B:
    try:
        r = float(A[key]) / float(B[key])
        p = float(A[key]) / float(C[key])
        f = p * r * 2 / (p + r)
        print "%s:\t p:%f\t r:%f\t f:%f" % (key,p,r,f)
    except:
        print "error:", key, "right:", A.get(key,0), "real:", B.get(key,0), "predict:",C.get(key,0)




