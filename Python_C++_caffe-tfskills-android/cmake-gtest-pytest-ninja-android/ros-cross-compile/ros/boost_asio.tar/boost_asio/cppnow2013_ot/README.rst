Built and tested with Boost 1.53 and GCC 4.7.2 (Linux x86-64).
