school(ucsd).
school(ucb).
school(ucla). 
school(uci). 
school(occ). 
school(smc).

armed_forces(army).
armed_forces(navy).
armed_forces(air_force).
armed_forces(marines).

peace_corps(peace_corps).
