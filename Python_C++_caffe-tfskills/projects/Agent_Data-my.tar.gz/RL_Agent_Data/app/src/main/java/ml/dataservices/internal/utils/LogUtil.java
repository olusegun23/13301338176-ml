package ml.dataservices.internal.utils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


/**
 * Created by haijunz on 17-9-26.
 */


public class LogUtil {


    public static StringBuilder readLogs() {
        StringBuilder logBuilder = new StringBuilder();
        try {

          //  Process process = Runtime.getRuntime().exec("logcat -b all -c");
            Process process1 = Runtime.getRuntime().exec("logcat -d -v time");
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(process1.getInputStream()));

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logBuilder.append(line + "\n");
            }
        } catch (IOException e) {
        }
        return logBuilder;
    }
}
