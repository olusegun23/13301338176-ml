package ml.dataservices.internal.algorithm.agents;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.algorithm.controllers.Screen;
import ml.dataservices.internal.utils.Globals;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.lang.Thread.sleep;


public class Rule_RL extends Service {


    private static  String TAG = Rule_RL.class.getSimpleName();
    Globals g ;
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used
    boolean mtest=true;
    public Rule_RL() {



    }

    @Override
    public void onCreate() {
        // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+".."+ b);
       // https://developer.android.com/reference/android/app/ActivityManager.RecentTaskInfo.html
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        // g = (Globals)getApplication();
        g = Globals.getInstance();
        // g.metaContext=MetaContext.getInstance();
        g.metaContext= g.metaContext.getInstance();
        g.metaContext.mDPC.mData="DPC_state:0,DPC_CurrentStateProb:0.0" ;

       /* UserManager userManager = (UserManager)getSystemService(Context.USER_SERVICE);
        UserHandle me = android.os.Process.myUserHandle();
        long serialNumber = userManager.getSerialNumberForUser(me);
     */

       /* BatteryManager mBatteryManager =(BatteryManager) getSystemService(Context.BATTERY_SERVICE);
        Long energy = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);*/
        // adb shell settings get system screen_brightness
        // Example of a call to a native method

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);
               //Creating new thread for my service
        //Always write your long running tasks in a separate thread, to avoid ANR

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    while (g.isRunning) {
                       sleep(g.mServicesSleepTime);
                       if (g.ScreenOff)  {
                           Action_Screen_Off();
                           Log.d(TAG, "g.ScreenOff==true Action_Screen_Off() " + Thread.currentThread().getStackTrace()[2]);
                           sleep(20000);
                           Action_Screen_ON();
                           Log.d(TAG, "g.ScreenOff==true Action_Screen_On() " + Thread.currentThread().getStackTrace()[2]);
                           g.ScreenOff=false;

                       }

                        //String s = "DPC_state:1,DPC_CurrentStateProb:0.0";
                            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--Rule_RL:g.metaContext.mDPC.mData="+g.metaContext.mDPC.mData);
                            Matcher m = Pattern.compile("\\d+").matcher(g.metaContext.mDPC.mData.substring(0, 18));
                            List<Integer> numbers = new ArrayList<Integer>();
                            while (m.find()) {
                                numbers.add(Integer.parseInt(m.group()));
                            }

                            Matcher m1 = Pattern.compile("\\d+").matcher(g.metaContext.mDPC.mData.substring(18));
                            List<Float> numbers1 = new ArrayList<Float>();
                            while (m1.find()) {
                                numbers1.add(Float.parseFloat(m1.group()));
                            }


                            switch (numbers.get(0)) {
                                case 1:
                                    Action_Screen_Off();
                                    Log.d(TAG, "g.ScreenOff==true Action_Screen_Off() " + Thread.currentThread().getStackTrace()[2]);
                                    break;

                                case 2:
                                    Action_Screen_Off();
                                    Log.d(TAG, "g.ScreenOff==true Action_Screen_Off() " + Thread.currentThread().getStackTrace()[2]);
                                    break;

                                case 3:
                                    Action_Screen_ON();
                                    Log.d(TAG, "g.ScreenOff==true Action_Screen_Off() " + Thread.currentThread().getStackTrace()[2]);
                                    break;

                                case 4:
                                    Action_Screen_ON();
                                    Log.d(TAG, "g.ScreenOff==false Action_Screen_On() " + Thread.currentThread().getStackTrace()[2]);
                                    break;

                                case 5:
                                    Action_Screen_Off();
                                    Log.d(TAG, "g.ScreenOff==true Action_Screen_Off() " + Thread.currentThread().getStackTrace()[2]);
                                    break;

                                default:
                                    Action_Screen_ON();
                                    Log.d(TAG, "g.ScreenOff==false Action_Screen_On() " + Thread.currentThread().getStackTrace()[2]);
                                    break;

                            }

                            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--Rule_RL: status="+numbers.get(0)+"   Prod="+numbers1.get(0));
                // SCREEN_OFF_TIMEOUT   SOUND_EFFECTS_ENABLED  VIBRATE_ON VIBRATE_WHEN_RINGING
                       // int curBrightnessValue=android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS,-1);

                     // SCREEN_OFF_TIMEOUT   SOUND_EFFECTS_ENABLED  VIBRATE_ON VIBRATE_WHEN_RINGING
                            int curBrightnessValue=android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS,-1);
                            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--Rule_RL=="+curBrightnessValue);

                           /* if (mtest==true) {


                               android.provider.Settings.System.putInt(getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                               Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS, -1);

                                mtest=false;


                            } else {


                                android.provider.Settings.System.putInt(getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                                Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,254);

                                mtest=true;

                            }*/

                            /* String myExec = "sh settings get system screen_brightnes";
                            StringBuilder result=new StringBuilder();
                            final StringBuilder append = result.append("....");
                            Process process;
                            try {
                                process = Runtime.getRuntime().exec("am start -a android.intent.action.MAIN -n com.android.settings/.Settings");
                                process = Runtime.getRuntime().exec("getprop  ro.sf.lcd_density");
                                process = Runtime.getRuntime().exec("cat /sys/class/leds/lcd-backlight/brightness");
                                process = Runtime.getRuntime().exec("cat /sys/class/power_supply/battery/current_now");
                                process.waitFor();
                                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                                String s = reader.readLine();
                                long currentTime = System.currentTimeMillis();
                            }
                            catch(Exception e) {
                                e.printStackTrace();
                            }  */



                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }


                       }

        }).start();

        return Service.START_STICKY;
            //return mStartMode;

    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {


        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }


    public void Action_Screen_Off() {

        Screen s = new Screen(this);
        s.turnOffScreen2();

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }


    public void Action_Screen_ON() {

        Screen s = new Screen(this);
        s.turnOnScreen2();

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }



}



