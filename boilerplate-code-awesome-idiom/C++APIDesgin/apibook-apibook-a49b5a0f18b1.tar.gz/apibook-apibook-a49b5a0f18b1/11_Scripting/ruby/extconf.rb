require 'mkmf'
create_makefile('phonebook')
