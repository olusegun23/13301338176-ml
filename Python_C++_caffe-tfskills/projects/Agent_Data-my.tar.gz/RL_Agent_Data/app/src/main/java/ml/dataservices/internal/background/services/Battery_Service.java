package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.BatteryManager;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.datastructure.MetaContext;
import ml.dataservices.internal.utils.Globals;

import static java.lang.Thread.sleep;


public class Battery_Service extends Service {


    private static  String TAG = Battery_Service.class.getSimpleName();
    Globals g ;
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used
    private MetaContext one = MetaContext.getInstance();
    BatteryManager mBatteryManager;

    public Battery_Service() {

    }

    @Override
    public void onCreate() {

        // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+".."+ b);
       // https://developer.android.com/reference/android/app/ActivityManager.RecentTaskInfo.html

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        // g = (Globals)getApplication();
        g= Globals.getInstance();
          /* UserManager userManager = (UserManager)getSystemService(Context.USER_SERVICE);
        UserHandle me = android.os.Process.myUserHandle();
        long serialNumber = userManager.getSerialNumberForUser(me);
     */

        mBatteryManager =(BatteryManager) getSystemService(Context.BATTERY_SERVICE);

        // adb shell settings get system screen_brightness
        // Example of a call to a native method

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);
               //Creating new thread for my service
        //Always write your long running tasks in a separate thread, to avoid ANR
        new Thread(new Runnable() {

            @Override
            public void run() {


                 try {
                    while (g.isRunning) {

                       sleep(g.mServicesSleepTime);
                        // SCREEN_OFF_TIMEOUT   SOUND_EFFECTS_ENABLED  VIBRATE_ON VIBRATE_WHEN_RINGING
                        Long energy = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                        g.metaContext.mBatteryInfo.mCreateTime= Calendar.getInstance();
                        g.metaContext.mBatteryInfo.mData="BATTERY_PROPERTY_CURRENT_NOW:"+energy;
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--BATTERY_PROPERTY_CURRENT_NOW(Instantaneous battery current in microamperes)=="+energy);




                        /* String myExec = "sh settings get system screen_brightnes";
                        StringBuilder result=new StringBuilder();
                        final StringBuilder append = result.append("....");
                        Process process;
                        try {
                            process = Runtime.getRuntime().exec("am start -a android.intent.action.MAIN -n com.android.settings/.Settings");
                            process = Runtime.getRuntime().exec("getprop  ro.sf.lcd_density");
                            process = Runtime.getRuntime().exec("cat /sys/class/leds/lcd-backlight/brightness");
                            process = Runtime.getRuntime().exec("cat /sys/class/power_supply/battery/current_now");
                            process.waitFor();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                            String s = reader.readLine();
                            long currentTime = System.currentTimeMillis();
                        }
                        catch(Exception e) {
                            e.printStackTrace();
                        }  */



                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }




            }
        }).start();



        return Service.START_STICKY;
            //return mStartMode;




    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {


        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }





}



