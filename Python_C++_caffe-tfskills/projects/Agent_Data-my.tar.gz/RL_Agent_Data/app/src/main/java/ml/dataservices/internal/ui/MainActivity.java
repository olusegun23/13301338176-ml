package ml.dataservices.internal.ui;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;


import ml.dataservices.R;

import static java.lang.Thread.sleep;
import ml.dataservices.external.lbs.*;

import ml.dataservices.internal.algorithm.agents.Rule_RL;
import ml.dataservices.internal.background.services.Event_Service;
import ml.dataservices.internal.background.services.SAMPLE_FUSE_Service;
import ml.dataservices.internal.background.services.*;

import ml.dataservices.internal.background.services.VR_Service_HW;
import ml.dataservices.internal.utils.Globals;


 public class MainActivity extends Activity {
    private static String TAG = MainActivity.class.getSimpleName();

    //  update UI


    TextView tv;
    Button button1;


    Handler mHandler = new Handler() {


        @Override
        public void handleMessage(Message msg) {

            if (msg.what == 1) {

                Globals g = (Globals) Globals.getInstance();
                tv = (TextView) findViewById(R.id.cpu);
                // tv.setText("Last DUMP time :" + g.metaContext.mDumpTime.getTimeInMillis() + "\n" + g.metaContext.mDPC.mData);

                tv.setText(""+g.metaContext);

                // tv.setText(stringFromJNI()+"Last DUMP time :"+g.metaContext.mDumpTime.getTimeInMillis());
                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + "DUMP time :" + g.metaContext.mDumpTime.getTimeInMillis());

                // get usage stats for the last 10 seconds
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       setContentView(R.layout.activity_main);

       if (null == savedInstanceState) {
            getFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container, Camera2BasicFragment.newInstance())
                    .commit();
        }



       /*button1 = (Button) findViewById(R.id.camera_on);
       button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                   getFragmentManager()
                            .beginTransaction()
                            .replace(R.id.container, Camera2BasicFragment.newInstance())
                            .commit();


            }


        });
     */




        // Test_LBS();

        Intent intent_AMAP_Location_Service = new Intent(this.getApplicationContext(), AMAP_Location_Service.class);
        startService(intent_AMAP_Location_Service);
        Intent intent_SAMPLE = new Intent(this.getApplicationContext(), SAMPLE_FUSE_Service.class);
        startService(intent_SAMPLE);  //  commit UI broken ==polling powerKey haijunz)


        Intent intent_Audio_Service = new Intent(this.getApplicationContext(), Audio_Service.class);
        startService(intent_Audio_Service);
        Intent intent_Visual_Service = new Intent(this.getApplicationContext(), Visual_Service.class);
        startService(intent_Visual_Service);

        /*Intent intent_LBS = new Intent(this.getApplicationContext(), Location_Service.class);
        startService(intent_LBS);*/

        Intent intent_LCD = new Intent(this.getApplicationContext(), LCD_Service.class);
        startService(intent_LCD);

        Intent intent_DPC = new Intent(this.getApplicationContext(), DPC_Service.class);
        startService(intent_DPC);

        Intent intent_CMC = new Intent(this.getApplicationContext(), CMC_Service.class);
        startService(intent_CMC);

        Intent intent_Battery = new Intent(this.getApplicationContext(), Battery_Service.class);
        startService(intent_Battery);


        Intent intent_Time = new Intent(this.getApplicationContext(), Time_Service.class);
        startService(intent_Time);


        Intent intent_ScreenOnOff = new Intent(this.getApplicationContext(), ScreenOnOffUserpresnetUnlock_Service.class);
        startService(intent_ScreenOnOff);


        Intent intent_Touch = new Intent(this.getApplicationContext(), Touch_Service.class);
        startService(intent_Touch);

        Intent intent_Event = new Intent(this.getApplicationContext(), Event_Service.class);
        startService(intent_Event);

        Intent intent_Rule_RL = new Intent(this.getApplicationContext(), Rule_RL.class);
        startService(intent_Rule_RL);

        Intent intent_HeadSetPlug_Service = new Intent(this.getApplicationContext(), HeadSetPlug_Service.class);
        startService(intent_HeadSetPlug_Service);

        Intent intent_VR_Service_HW = new Intent(this.getApplicationContext(),VR_Service_HW.class);
        startService(intent_VR_Service_HW);

        Intent intent = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
        //startActivity(intent);


       /* final DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if(!dpm.isDeviceOwnerApp(getPackageName()))
        {
            Log.i(TAG, "====" + Thread.currentThread().getStackTrace()[2]+"App is not device owner, set it with `dpm set-device-owner it.denv.hwmonitor/.AdmRcvr` by adb shell and restart the app");

        }

        HardwarePropertiesManager hwpm = (HardwarePropertiesManager) getSystemService(this.HARDWARE_PROPERTIES_SERVICE);
        CpuUsageInfo cpuUsage[] = hwpm.getCpuUsages();
        Log.i(TAG, "====" + Thread.currentThread().getStackTrace()[2]+"length: %d  "+cpuUsage.length);

        for (CpuUsageInfo coreUsage : cpuUsage)
        {

            String cpu_tmp = String.format("%d / %d", coreUsage.getActive(), coreUsage.getTotal());
            Log.i(TAG,"mainActivity"+cpu_tmp);

        }*/

       /* Button resetOwner = (Button) new Button(this);
        resetOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(dpm.isDeviceOwnerApp(getPackageName()))
                {
                    dpm.clearDeviceOwnerApp(getPackageName());
                }
            }
        });*/


        Log.i(TAG, "====" + Thread.currentThread().getStackTrace()[2]);

       /* Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        }); */

        //  update UI
        new Thread(new Runnable() {


            Globals g = (Globals) Globals.getInstance();

            @Override
            public void run() {

                try {
                    while (g.isRunning) {
                        sleep(g.mServicesSleepTime);
                        Message msg = mHandler.obtainMessage();
                        msg.what = 1;
                        msg.sendToTarget();


                        ///Simulate GPS


                        //////


                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Globals g = (Globals) Globals.getInstance();
            g.ScreenOff = true;
            Log.i(TAG, "Going to sleep now.");

        }
        return true;

    }

    public native String stringFromJNI();



    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }


    public void Test_LBS() {

        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        Location mobileLocation;


// Define a listener that responds to location updates
        LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                // Called when a new location is found by the network location provider.

                if (location != null) {
                    Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " onLocationChanged:  " + location.toString());
                }
                ;
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {

                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);

            }

            public void onProviderEnabled(String provider) {

                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
            }

            public void onProviderDisabled(String provider) {

                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
            }
        };


        int status2 = getPackageManager().checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, getPackageName());


        // Or use LocationManager.GPS_PROVIDER
        //  java.lang.NullPointerException: Attempt to invoke virtual method 'java.lang.String android.location.Location.toString()' on a null object reference

        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, locationListener);

        mobileLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " onLocationChanged +begin:  ");

        if (mobileLocation != null) {
            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " onLocationChanged  mobileLocation "+mobileLocation);

        }

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " onLocationChanged +end:  ");

    }

}