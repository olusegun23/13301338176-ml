package ml.dataservices.internal.background.snapshot;

/**
 * Created by haijunz on 17-11-14.
 */

public abstract class  State {

     int last=0;
     public abstract void doAction(PowerKeyContext context,int current);
}
