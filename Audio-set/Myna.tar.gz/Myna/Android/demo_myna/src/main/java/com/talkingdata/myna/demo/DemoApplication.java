package com.talkingdata.myna.demo;

import android.app.Application;


public class DemoApplication extends Application{

    final static String TAG = "DemoLog";
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
