package ml.dataservices;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.icu.util.Calendar;
import android.os.HardwarePropertiesManager;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import ml.dataservices.internal.algorithm.controllers.ScreenAdminReceiver;

import org.junit.Test;
import org.junit.runner.RunWith;

import static android.content.ContentValues.TAG;
import static android.content.Context.HARDWARE_PROPERTIES_SERVICE;
import static org.junit.Assert.*;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        System.out.println("--..hour--"+ Calendar.getInstance().get(Calendar.HOUR));
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--..hour--"+ Calendar.getInstance().get(Calendar.HOUR));
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--..hour--"+ Calendar.getInstance().get(Calendar.HOUR_OF_DAY));

        assertEquals("com.qualcomm.qtl.datacollection", appContext.getPackageName());
    }


    @Test
    public void useHardwarePropertiesManager() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();
        DevicePolicyManager policyManager = (DevicePolicyManager) appContext.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminReceiver = new ComponentName(appContext.getApplicationContext(),ScreenAdminReceiver.class);
        boolean admin = policyManager.isAdminActive(adminReceiver);
        if (admin) {
            HardwarePropertiesManager s= (HardwarePropertiesManager) appContext.getSystemService(HARDWARE_PROPERTIES_SERVICE);
            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"   "+s.getFanSpeeds());
            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"   "+s.getCpuUsages());
            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"   "+s.DEVICE_TEMPERATURE_BATTERY);
            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"   "+s.DEVICE_TEMPERATURE_GPU);


        } else {
            Log.i(TAG, "Not an admin");
        }


    }



}
