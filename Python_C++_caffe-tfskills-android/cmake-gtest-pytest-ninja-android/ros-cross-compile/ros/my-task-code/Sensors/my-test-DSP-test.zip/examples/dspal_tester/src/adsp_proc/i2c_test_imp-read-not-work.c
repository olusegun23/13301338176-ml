/*==============================================================================
 Copyright (c) 2015 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/

#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <dev_fs_lib_i2c.h>

#include <dspal_errno.h>
#define FARF_MEDIUM 1
#include <HAP_farf.h>

 /**
* @brief Test to see i2c device can be opened and configured.
*
* @par
* Test:
* 1) Open the i2c device (/dev/iic-9)
* 2) Configure the i2c device to have (using ioctl):
*     -Slave address: 0x70
*     -Bus Frequency in khz: 400
*     -Transfer timeout in usec: 9000
* 3) Close the i2c device
*
* @return
* SUCCESS ------ Test Passes
* ERROR ------ Test Failed
*/
int dspal_tester_i2c_test(void)
{
   int ret = SUCCESS;
   /*
    * Open i2c device
    */
   int fd = -1;
  // fd = open("/dev/iic-9", 0);

     fd = open("/dev/iic-10", 0);

   if (fd > 0)
   {
      /*
       * Configure I2C device
       */

	   FARF(MEDIUM, "test  iic fd >0 ");
      struct dspal_i2c_ioctl_slave_config slave_config;
      slave_config.slave_address = 0x70;
      slave_config.bus_frequency_in_khz = 400;
      slave_config.byte_transer_timeout_in_usecs = 9000;
      if (ioctl(fd, I2C_IOCTL_CONFIG, &slave_config) != 0)
	  ret = ERROR;
      	
	  int read_cycle_count = 0;
	  char buf[1];








	  for (read_cycle_count = 0; read_cycle_count <200; read_cycle_count++)
	{
		int num_bytes_read;
		memset(buf, 0, sizeof(buf));
		num_bytes_read = read(fd, buf, sizeof(buf));
		FARF(MEDIUM, "iic read number of bytes read: %d", num_bytes_read);
		if (num_bytes_read > 0)
		{
			FARF(MEDIUM, "iic test read  bytes of %d in buffer:[[  %d ]]", num_bytes_read,*buf);
		}
		usleep(100000); /* delay xxx milliseconds */

	  }


	  /*
       * Close the device ID
       */
	  close(fd);

	  FARF(MEDIUM, "test  iic-10-2  opmn close sucess");
   }
   else
      ret = ERROR;

   return ret;
}
