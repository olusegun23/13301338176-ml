

package ml.dataservices.internal.background.services;
import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import ml.dataservices.internal.background.receivers.Screen_ChangeReceiver;
import ml.dataservices.internal.utils.Globals;
import static java.lang.Thread.sleep;

public class CellId_Service extends Service {


    private static  String TAG = CellId_Service.class.getSimpleName();
    private TelephonyManager mTelephonyManager=null;


    public CellId_Service() {
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        mTelephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
             new Thread(new Runnable() {

            @Override
            public void run() {

                Globals g = Globals.getInstance();

                try {
                    while (g.isRunning) {
                        sleep(g.mServicesSleepTime);

                        String operator = mTelephonyManager.getNetworkOperator();
                        String mcc = operator.substring(0, 3);
                        String mnc = operator.substring(3);

                        // Log.i(TAG, " MCC = " + mcc + "\t MNC = " + mnc + "\t LAC = " + lac + "\t CID = " + cellI

                        int  status1 = getPackageManager().checkPermission(Manifest.permission.READ_PHONE_STATE,getPackageName());


                     //   TelephonyManager.

                        if(mTelephonyManager.getPhoneType() == TelephonyManager.PHONE_TYPE_CDMA){
                            CdmaCellLocation cdmaCellLocation = (CdmaCellLocation) mTelephonyManager.getCellLocation();
                            int cid = cdmaCellLocation.getBaseStationId(); //获取cdma基站识别标号 BID
                            int lac = cdmaCellLocation.getNetworkId(); //获取cdma网络编号NID
                            int sid = cdmaCellLocation.getSystemId(); //用谷歌API的话cdma网络的mnc要用这个getSystemId()取得→SID
                        }else{
                            GsmCellLocation gsmCellLocation = (GsmCellLocation) mTelephonyManager.getCellLocation();
                            int cid = gsmCellLocation.getCid(); //获取gsm基站识别标号
                            int lac = gsmCellLocation.getLac(); //获取gsm网络编号
                        }



//                      Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--LCD=="+curBrightnessValue);




                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }




            }
        }).start();



        return Service.START_STICKY;
        //return mStartMode;


    }



    @Override
    public void onDestroy() {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }



}
