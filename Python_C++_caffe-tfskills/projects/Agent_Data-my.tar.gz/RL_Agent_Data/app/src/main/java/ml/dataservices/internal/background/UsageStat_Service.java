package ml.dataservices.internal.background;

import android.app.ActivityManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.datastructure.MetaContext;

import java.util.List;

import static java.lang.Thread.sleep;

public class UsageStat_Service extends Service {


    private MetaContext one = MetaContext.getInstance();

    public UsageStat_Service() {
    }

    private static  String TAG = "";

    private boolean isRunning  = false;

    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    @Override
    public void onCreate() {

        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);

        StringBuilder b = new StringBuilder();
        for (ActivityManager.RunningAppProcessInfo process: am.getRunningAppProcesses()) {
            b.append(process.processName);
            b.append("\n");
        }

        // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+".."+ b);
        // https://developer.android.com/reference/android/app/ActivityManager.RecentTaskInfo.html

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);





    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);

        isRunning = true;

        //Creating new thread for my service
        //Always write your long running tasks in a separate thread, to avoid ANR
        new Thread(new Runnable() {


            UsageStatsManager mUsageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);

            String daysArray[] = {"Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday", "Saturday"};

            @Override
            public void run() {
                 try {
                    while (isRunning) {
                        sleep(1000);

                        int hour = Calendar.getInstance().get(Calendar.HOUR);
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--hour--"+hour);

                        int day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--day--::"+daysArray[day]);

                        long currentTime = System.currentTimeMillis();
                            // get usage stats for the last 10 seconds



                        /* UsageEvents usageEvents = mUsageStatsManager.queryEvents(currentTime - 100 * 1000,currentTime);
                        UsageEvents.Event event = new UsageEvents.Event();
                        // get last event
                        while (usageEvent.hasNextEvent()) {
                            usageEvent.getNextEvent(event);
                        }
                        if (foregroundApp.equals(event.getPackageName()) && event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                            return foregroundApp ;
                        }*/

                        //https://stackoverflow.com/questions/33307042/android-6-0-marshmallow-usagestatsmanager-issue-when-trying-to-retrieve-foregrou

                       // https://stackoverflow.com/questions/27563401/using-usagestats-gettotaltimeinforeground-to-get-the-time-every-application-in
                           // List<UsageStats> stats = mUsageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, currentTime -1000*2 , currentTime);


                        // https://www.programcreek.com/java-api-examples/index.php?class=android.app.usage.UsageStatsManager&method=queryUsageStats
                            // https://github.com/googlesamples/android-AppUsageStatistics
                            // search for app with most recent last used time



                        int interval = UsageStatsManager.INTERVAL_YEARLY;
                        Calendar calendar = Calendar.getInstance();
                        long endTime = calendar.getTimeInMillis();
                        calendar.add(Calendar.YEAR, -1);
                        long startTime = calendar.getTimeInMillis();

                        Log.i(TAG, "::::" + ml.dataservices.internal.utils.LogUtil.readLogs());



                        List<UsageStats> stats = mUsageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, startTime,endTime);

                        UsageEvents events = mUsageStatsManager.queryEvents(startTime,endTime);

                        if (stats != null) {

                            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + "**");


                            long lastUsedAppTime = 0;

                            String topPackageName;
                            for (UsageStats usageStats : stats) {

                                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + "*5*");

                                topPackageName = usageStats.getPackageName();
                                lastUsedAppTime = usageStats.getLastTimeUsed();


                                //if (usageStats.getLastTimeUsed() > lastUsedAppTime) {TotalTimeInForeground


                                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + "+" + topPackageName);

                                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + ":" + lastUsedAppTime);

                                Log.d(TAG, "Usages: " + usageStats.getPackageName() +" , TotalTimeInForeground: "+usageStats.getTotalTimeInForeground() + " timestamp: \t" );
                                //}
                            }

                        }

                        while (events.hasNextEvent()){
                            UsageEvents.Event e = new UsageEvents.Event();
                            events.getNextEvent(e);


                            if (e != null) {
                                int event_type=e.getEventType();
                                String event_name;
                                switch (event_type) {
                                    case UsageEvents.Event.MOVE_TO_FOREGROUND:
                                        event_name= "Foreground";

                                    case UsageEvents.Event.MOVE_TO_BACKGROUND:
                                        event_name= "Background";

                                    case UsageEvents.Event.CONFIGURATION_CHANGE:
                                        event_name= "Config change";

                                    case UsageEvents.Event.USER_INTERACTION:
                                        event_name= "User Interaction";

                                    case UsageEvents.Event.SHORTCUT_INVOCATION:
                                        event_name= "SHORTCUT_INVOCATION";

                                    default:
                                        event_name="Unknown: " + event_type;
                                }

                                Log.d(TAG, "Event: " + e.getPackageName() +"==="+event_name+ " timestamp: \t" + e.getTimeStamp());
                            }


                        }

                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();



        return Service.START_STICKY;
            //return mStartMode;




    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {

        isRunning = false;

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

}



