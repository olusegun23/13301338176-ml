/*==============================================================================
  Copyright (c) 2015 Qualcomm Technologies, Inc.
  All rights reserved. Qualcomm Proprietary and Confidential.
==============================================================================*/

#ifndef TEST_UTILS_H
#define TEST_UTILS_H

#include <time.h>
#include <stdint.h>
#include <errno.h>

#include "dspal_errno.h"

#define TEST_PASS  0x00
#define TEST_FAIL  0x01
#define TEST_SKIP  0x02

#ifndef TRUE
#define TRUE (1 == 1)
#endif

#ifndef FALSE
#define FALSE (1 != 1)
#endif

#ifdef __hexagon__
/* Use the following macro for debug output on the aDSP. */
#define FARF_MEDIUM 1
#include <HAP_farf.h>
#define MSG(...) FARF(ALWAYS, __VA_ARGS__);
#else
/* Use the following macro for debug output on the Application Processor. */
#include <stdio.h>
#define MSG(...) printf(__VA_ARGS__);
#endif

#define FAIL(msg) { \
  { test_failed(msg, __FILE__, __LINE__); return TEST_FAIL; } \
}

int display_test_results(int result, const char *label);

void log_error(const char *error);

const char *get_result_string(int result);

void test_failed(const char *msg, const char *file, int lineNumber);

time_t time(time_t *t);

#endif // TEST_UTILS_H
