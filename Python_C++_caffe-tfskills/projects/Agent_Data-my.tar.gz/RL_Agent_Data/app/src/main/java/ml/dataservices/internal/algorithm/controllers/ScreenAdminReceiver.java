package ml.dataservices.internal.algorithm.controllers;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by haijunz on 17-11-7.
 */
/**
 * Receiver class which shows notifications when the Device Administrator status
 * of the application changes.
 */
public class ScreenAdminReceiver extends DeviceAdminReceiver {

    private void showToast(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        showToast(context,""+Thread.currentThread().getStackTrace()[2]);
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        showToast(context,""+Thread.currentThread().getStackTrace()[2]);
    }





}
