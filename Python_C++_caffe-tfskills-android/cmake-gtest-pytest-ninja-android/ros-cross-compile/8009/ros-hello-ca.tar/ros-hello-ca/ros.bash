export PATH=$PATH:/opt/cmake-3.4.3-Linux-x86_64/bin
export APQ8009_LEUM_ROOT=/prj/atlanticus/releases/8009/LE.UM.0.0_040617_robot/cross-compile-toolchain
export tmp_x86root=$APQ8009_LEUM_ROOT/x86_64-linux
export ROS_ROOT=$APQ8009_LEUM_ROOT/apq8009-robot/opt/ros/indigo
export PATH=$tmp_x86root/opt/ros/indigo/bin:$PATH
export PYTHONPATH=$APQ8009_LEUM_ROOT/apq8009-robot/opt/ros/indigo/lib/python2.7/site-packages:/usr/share/pyshared
export PKG_CONFIG_PATH=$APQ8009_LEUM_ROOT/apq8009-robot/opt/ros/indigo/lib/pkgconfig
export CMAKE_PREFIX_PATH=$APQ8009_LEUM_ROOT/apq8009-robot/opt/ros/indigo
export ROS_ETC_DIR=$APQ8009_LEUM_ROOT/apq8009-robot/opt/ros/indigo/etc/ros
export ROS_PACKAGE_PATH=$APQ8009_LEUM_ROOT/apq8009-robot/pkgdata
touch $APQ8009_LEUM_ROOT/apq8009-robot/opt/ros/indigo/.catkin
export ROS_DISTRO=indigo
echo catkin_make --cmake-args -DCMAKE_TOOLCHAIN_FILE=/prj/atlanticus/releases/8009/LE.UM.0.0_040617_robot/Toolchain-arm-8009-oe.cmake

