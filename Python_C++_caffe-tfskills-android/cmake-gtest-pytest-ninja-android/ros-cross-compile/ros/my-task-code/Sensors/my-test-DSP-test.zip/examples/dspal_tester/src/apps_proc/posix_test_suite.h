/*==============================================================================
  Copyright (c) 2015 Qualcomm Technologies, Inc.
  All rights reserved. Qualcomm Proprietary and Confidential.
==============================================================================*/

#ifndef POSIX_TEST_SUITE_H
#define POSIX_TEST_SUITE_H

#include "AEEStdDef.h"

/**
 * @brief Runs all the posix tests.
 * 
 * @par
 * Tests that are run (in order)
 * 1) dspal_tester_test_clockid
 * 2) dspal_tester_test_sigevent
 * 3) dspal_tester_test_time
 * 4) dspal_tester_test_timer_realtime_sig_none
 * 5) dspal_tester_test_timer_monotonic_sig_none
 * 6) dspal_tester_test_timer_process_cputime_sig_none
 * 7) dspal_tester_test_timer_thread_cputime_sig_none
 * 8) dspal_tester_test_time_return_value
 * 9) dspal_tester_test_time_param
 * 10) dspal_tester_test_usleep
 * 11) dspal_tester_test_clock_getres
 * 12) dspal_tester_test_clock_gettime
 * 13) dspal_tester_test_clock_settime
 * 14) dspal_tester_test_one_shot_timer_cb
 * 15) dspal_tester_test_periodic_timer_cb
 * 16) dspal_tester_test_periodic_timer_signal_cb
 * 17) dspal_tester_test_periodic_timer_sigwait
 * 18) dspal_tester_test_pthread_attr_init
 * 19) dspal_tester_test_pthread_create
 * 20) dspal_tester_test_pthread_cancel
 * 21) dspal_tester_test_pthread_self
 * 22) dspal_tester_test_pthread_exit
 * 23) dspal_tester_test_pthread_kill
 * 24) dspal_tester_test_pthread_mutex_lock
 * 25) dspal_tester_test_pthread_mutex_lock_thread
 * 26) dspal_tester_test_pthread_stack
 * 27) dspal_tester_test_pthread_heap
 * 28) dspal_tester_test_usleep
 * 29) dspal_tester_test_semaphore_wait
 *
 * @return
 * TEST_PASS ------ All tests passed
 * TEST_FAIL ------ One or more tests failed
*/
int run_posix_test_suite();

#endif // POSIX_TEST_SUITE_H
