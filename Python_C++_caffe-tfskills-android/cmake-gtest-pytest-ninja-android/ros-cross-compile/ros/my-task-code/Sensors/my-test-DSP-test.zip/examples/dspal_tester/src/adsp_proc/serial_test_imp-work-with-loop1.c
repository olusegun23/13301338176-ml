/*==============================================================================
Copyright (c) 2015 Qualcomm Technologies, Inc.
All rights reserved. Qualcomm Proprietary and Confidential.
==============================================================================*/

#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <dev_fs_lib_serial.h>

#include <stdlib.h>


/* Enable medium level debugging. */
#define FARF_MEDIUM 1  /* 0 turns me off */
#include <HAP_farf.h>

#include "dspal_errno.h"
#include "test_utils.h"
//#include "dspal_tester.h"
#include <stdlib.h>


#define SERIAL_READ_CYCLES 5
#define SERIAL_SIZE_OF_DATA_BUFFER_B 100
int read_cycle_count = 0;




int dspal_tester_serial_read_with_small_buffer(void)
{
	int result = SUCCESS;
	int num_bytes_read = 0;
	char rx_buffer[SERIAL_SIZE_OF_DATA_BUFFER_B];
	int fd;
	FARF(MEDIUM, "beginning tty-3 serial test read with small buffer test");
	fd = open("/dev/tty-3", O_RDWR);
	FARF(HIGH, " tty-3 serial test  open %s O_RDWR mode %s", "tty-3",
		(fd < SUCCESS) ? "fail":"succeed");
	if (fd < SUCCESS)
	{
		result = ERROR;
		goto exit;
	}

	for (read_cycle_count = 0; read_cycle_count <5; read_cycle_count++)
	{

				
readloop:
		memset(rx_buffer, 0, SERIAL_SIZE_OF_DATA_BUFFER_B);
		num_bytes_read = read(fd, rx_buffer, SERIAL_SIZE_OF_DATA_BUFFER_B);
		if (num_bytes_read < 1)
		{
			FARF(MEDIUM, "tty-3 serial test  read()  ****** return expected  code[%d]",num_bytes_read);
			goto readloop;
		} else 
		{
			FARF(MEDIUM, "%s  FARF serial test read bytes [%d]: %s","/dev/tty-3", num_bytes_read, rx_buffer);

			FARF(MEDIUM, "FARF serial test read int  [%d]:" , atoi(rx_buffer) );
		}
	}

exit:
	if (fd >= SUCCESS)
	{
		close(fd);
	}

	FARF(HIGH, "serial read with small buffer test %s",
		result == SUCCESS ? "PASSED":"FAILED");

	return result;
}

/**
* @brief Runs all the serial tests and returns 1 aggregated result.
*
* @return
* SUCCESS ------ All tests pass
* ERROR -------- One or more tests failed
*/
int dspal_tester_serial_test(void)
{
	int result;
	FARF(MEDIUM, "beginning serial read test=======================");
	if ((result =dspal_tester_serial_read_with_small_buffer()) < SUCCESS)
	{
		FARF(HIGH, "error: serial port read test failed: %d", result);
		return result;
	}
	FARF(MEDIUM, "serial port read/write test succeeded==================");
	return result;


}
