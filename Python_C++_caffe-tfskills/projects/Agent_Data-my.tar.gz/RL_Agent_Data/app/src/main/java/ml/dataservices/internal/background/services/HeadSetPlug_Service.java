package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import ml.dataservices.internal.background.receivers.HeadSetPlug_Receiver;
import ml.dataservices.internal.background.receivers.Screen_ChangeReceiver;

public class HeadSetPlug_Service extends Service {
    public HeadSetPlug_Service() {
    }

    private static  String TAG = HeadSetPlug_Service.class.getSimpleName();
    private HeadSetPlug_Receiver mHeadSetPlug_Receiver;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        registerScreenStatusReceiver();
    }

    @Override
    public void onDestroy() {
        unregisterScreenStatusReceiver();
    }

    private void registerScreenStatusReceiver() {
        mHeadSetPlug_Receiver = new HeadSetPlug_Receiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_HEADSET_PLUG);
        registerReceiver(mHeadSetPlug_Receiver, filter);
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    private void unregisterScreenStatusReceiver() {
        try {
            if (mHeadSetPlug_Receiver != null) {
                unregisterReceiver(mHeadSetPlug_Receiver);
            }
        } catch (IllegalArgumentException e) {}

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }
}





