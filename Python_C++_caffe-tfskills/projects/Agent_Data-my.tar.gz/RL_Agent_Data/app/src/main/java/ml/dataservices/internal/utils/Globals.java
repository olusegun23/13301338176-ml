package ml.dataservices.internal.utils;

import ml.dataservices.internal.datastructure.MetaContext;

/**
 * Created by haijunz on 17-11-2.
 */

public final class Globals {

    private  static Globals mSingleton;
    public  boolean isRunning=true;
    public  boolean ScreenOff=false;
    public  int mServicesSleepTime=200;  //ms
    public  MetaContext metaContext = MetaContext.getInstance();


    private Globals() {

        if (mSingleton != null) {
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }


    public static  Globals getInstance() {

       //Double check locking pattern

        if (mSingleton == null) {  //Check for the first time
            synchronized (Globals.class) {   //Check for the second time.
                //if there is no instance available... create new one
                if (mSingleton == null) mSingleton = new Globals();
            }


        }

        return mSingleton;
    }



}
