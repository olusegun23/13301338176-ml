package ml.dataservices.internal.datastructure;

import java.util.List;

/**
 * Created by haijunz on 17-10-19.
 */


public interface DataRepository<T> {
    void add(T item);
    void remove(T item);
    List<T> query();

}
