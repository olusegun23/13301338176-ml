package ml.dataservices.internal.background.receivers;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.AsyncTask;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;

import ml.dataservices.internal.utils.Globals;


/**
 * Created by haijunz on 17-11-6.
 */

public class ALL_Intent_ChangeReceiver extends BroadcastReceiver  {


    private static  String TAG = ALL_Intent_ChangeReceiver.class.getSimpleName();
    Globals g ;
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    @Override
    public void onReceive(Context context, Intent intent) {

       // g = (Globals)getApplication();
//        g.metaContext= MetaContext.getInstance();

        final Intent intent1;

        StringBuilder sb = new StringBuilder();
        sb.append("Action: " + intent.getAction() + "\n");
        sb.append("URI: " + intent.toUri(Intent.URI_INTENT_SCHEME).toString() + "\n");
        String log = sb.toString();
        String action = intent.getAction();
        Log.d(TAG, "zhj-..."+log);


        if(intent.getAction().equals(Intent.ACTION_AIRPLANE_MODE_CHANGED)) {

                Log.d("Airplane Mode", "Airplane mode changed");
                boolean airplaneMode = Settings.Global.getInt(context.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
                g = Globals.getInstance();
                g.metaContext.mAIRPLANE_MODE.mCreateTime= Calendar.getInstance();

                if (airplaneMode)  {
                    g.metaContext.mAIRPLANE_MODE.mData="AIRPLANE_MODE: TRUE";

                } else {

                    g.metaContext.mAIRPLANE_MODE.mData="AIRPLANE_MODE: FALSE";
                }


            }


       /* 2-01 13:51:34.798 21785 21785 D ALL_Intent_ChangeReceiver: zhj-...Action: android.intent.action.AIRPLANE_MODE
        12-01 13:51:34.798 21785 21785 D ALL_Intent_ChangeReceiver: URI: intent:#Intent;action=android.intent.action.AIRPLANE_MODE;launchFlags=0x10;component=ml.dataservices/.internal.background.receivers.ALL_Intent_ChangeReceiver;B.state=true;end
        12-01 13:51:38.480 21785 21785 D ALL_Intent_ChangeReceiver: zhj-...Action: android.intent.action.AIRPLANE_MODE
        12-01 13:51:38.480 21785 21785 D ALL_Intent_ChangeReceiver: URI: intent:#Intent;action=android.intent.action.AIRPLANE_MODE;launchFlags=0x10;component=ml.dataservices/.internal.background.receivers.ALL_Intent_ChangeReceiver;B.state=false;end

    */




      /* final PendingResult pendingResult = goAsync();
        AsyncTask<String, Integer, String> asyncTask = new AsyncTask<String, Integer, String>() {
            @Override
            protected String doInBackground(String... params) {
                StringBuilder sb = new StringBuilder();
                sb.append("Action: " + intent.getAction() + "\n");
                sb.append("URI: " + intent.toUri(Intent.URI_INTENT_SCHEME).toString() + "\n");
                Log.d(TAG, log);
                // Must call finish() so the BroadcastReceiver can be recycled.
               // pendingResult.finish();
                return data;
            }
        };
        asyncTask.execute();  */


    }   // end onReceive


}
