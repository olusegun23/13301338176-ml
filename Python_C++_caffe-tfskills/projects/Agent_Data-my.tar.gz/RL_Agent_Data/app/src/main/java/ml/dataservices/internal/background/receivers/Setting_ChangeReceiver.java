package ml.dataservices.internal.background.receivers;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.utils.Globals;


/**
 * Created by haijunz on 17-11-6.
 */

public class Setting_ChangeReceiver extends BroadcastReceiver  {


    private static  String TAG = Setting_ChangeReceiver.class.getSimpleName();
    Globals g ;
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    @Override
    public void onReceive(Context context, Intent intent) {

       // g = (Globals)getApplication();
//        g.metaContext= MetaContext.getInstance();


        StringBuilder sb = new StringBuilder();
        sb.append("Action: " + intent.getAction() + "\n");
        sb.append("URI: " + intent.toUri(Intent.URI_INTENT_SCHEME).toString() + "\n");
        String log = sb.toString();
        String action = intent.getAction();
        Log.d(TAG, "zhj-..."+log);

        /*g = (Globals) Globals.getInstance();
        g.ScreenOff=false;
        Log.d(TAG, "g.ScreenOff=false..."); */



    }






}
