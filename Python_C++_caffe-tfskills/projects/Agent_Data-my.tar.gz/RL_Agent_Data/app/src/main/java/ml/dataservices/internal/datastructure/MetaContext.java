package ml.dataservices.internal.datastructure;

import android.icu.text.SimpleDateFormat;

import java.io.Serializable;

import java.util.Observable;

import static java.lang.Thread.sleep;

/**
 * Created by haijunz on 17-10-18.
 */

public class MetaContext extends Observable implements Runnable, Serializable  {
    private static final String TAG = "MetaContext";
    private static volatile MetaContext mMetaContext;
    public android.icu.util.Calendar mDumpTime =  android.icu.util.Calendar.getInstance();
    public ContextItem mTime= new ContextItem();                       // phase1
    public ContextItem mAppInfo =new ContextItem();              // phase1  forgroundApp
    public ContextItem mBatteryInfo = new ContextItem();// phase1
    public ContextItem mDPC= new ContextItem();
    public ContextItem mCMC= new ContextItem();
    // phase1
    public ContextItem mDeviceInfo =new ContextItem();     // phase 1 brightness, Screen_power_on-off,ulockun
    public ContextItem mScreenInfo=new ContextItem();
    public ContextItem mPowerKeyInfo=new ContextItem();
    public ContextItem mLocationInfo=new ContextItem();
    public ContextItem mAIRPLANE_MODE=new ContextItem();
    public ContextItem mHeadSetPlug=new ContextItem();
    public ContextItem mAudio=new ContextItem();
    public ContextItem mVisual=new ContextItem();

    /*IODItem mIOD =new IODItem() ;
    LocationItem mLocation = new LocationItem();
    UserMotionItem mUserMotion = new UserMotionItem() ;
    UserActivityItem mUserActivity = new UserActivityItem();
    PhonePositionItem mPhonePosition = new PhonePositionItem();

    ConcurrentLinkedQueue<WeatherItem> mWeatherQueue = new ConcurrentLinkedQueue<WeatherItem>();
    ConcurrentLinkedQueue<AppInfoItem> mAppInfoQueue = new ConcurrentLinkedQueue<AppInfoItem>();
    ConcurrentLinkedQueue<DeviceInfoItem> mDeviceInfoQueue = new ConcurrentLinkedQueue<DeviceInfoItem>();
    ConcurrentLinkedQueue<IODItem> mIODQueue = new ConcurrentLinkedQueue<IODItem>();
    ConcurrentLinkedQueue<LocationItem> mLocationQueue = new ConcurrentLinkedQueue<LocationItem>();
    ConcurrentLinkedQueue<UserMotionItem> mUserMotionQueue = new ConcurrentLinkedQueue<UserMotionItem>();
    ConcurrentLinkedQueue<UserActivityItem> mUserActivityQueue = new ConcurrentLinkedQueue<UserActivityItem>();
    ConcurrentLinkedQueue<PhonePositionItem> mPhonePositionQueue = new ConcurrentLinkedQueue<PhonePositionItem>();

*/


    public String toString(){

        // return "States DumpTime:"+mDumpTime.getTimeInMillis()+","+mTime+","+mAppInfo+","+mBatteryInfo+","+mDPC+","+mDeviceInfo+","+mScreenInfo+","+mPowerKeyInfo;
        // return "Sample_Time:"+mDumpTime.getTimeInMillis()+","+mTime.mData+","+mAppInfo.mData+","+mBatteryInfo.mData+","+mDPC.mData+","+mDeviceInfo.mData+","+mScreenInfo.mData+","+mPowerKeyInfo.mData;
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
       // SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-SSS");
      // return "Sample_Time:"+format1.format(mDumpTime.getTime())+",    "+mTime.mData+",    "+mBatteryInfo.mData+",    "+mCMC.mData+",    "+mDPC.mData+",    "+mDeviceInfo.mData+",    "+mScreenInfo.mData+",    "+mPowerKeyInfo.mData+",    "+mAIRPLANE_MODE.mData+",    "+mHeadSetPlug.mData+",    "+mAudio.mData+",    "+mVisual.mData+",    "+mLocationInfo.mData;

        return "Sample_Time:"+format1.format(mDumpTime.getTime())+"\n   时间感知："
                +mTime.mData+"\n   设备感知："+mBatteryInfo.mData+",    "+mCMC.mData+",    "+mDPC.mData+",    "+mDeviceInfo.mData+",    "+mScreenInfo.mData+",    "+mPowerKeyInfo.mData+",    "+mAIRPLANE_MODE.mData+",    "+mHeadSetPlug.mData+"\n  \n(Tensorflow in the paper Convolutional Neural Networks for Small-footprint Keyword Spotting. \n: 听觉感知："+mAudio.mData+"\n   \n (Tensorflow Lite MobileNet："+mVisual.mData+"\n   位置感知："+mLocationInfo.mData;



    };
   /* States DumpTime:1510711904470,CreateTime:1510711904184,hour:10,day of month:15,month:11,CreateTime:1510711897479,ForegroundApp:com.android.settings/.Settings,CreateTime:151
            0711903791,BATTERY_PROPERTY_CURRENT_NOW:8087,CreateTime:1510711847120,DPC:11 CurrentStateProb=1.78E-43,CreateTime:1510711904398,LCD Brightness:98,CreateTime:1510711260137,S
    creen_Info:ON,CreateTime:1510711904466,PowerKey:Free */
/*
   30.102261, -81.711777, Residential, Masonry, 1
            30.063936, -81.707664, Residential, Masonry, 3
            30.089579, -81.700455, Residential, Wood   , 1
            30.063236, -81.707703, Residential, Wood   , 3
            30.060614, -81.702675, Residential, Wood   , 1
*/

    private MetaContext() {
        //Prevent form the reflection api.
        if (mMetaContext != null) {
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
        mScreenInfo.mData="Screen_Info:"+"ON";
        mAIRPLANE_MODE.mData="AIRPLANE_MODE: FALSE";
        mHeadSetPlug.mData="HeadSetPlug: NO";
        mAudio.mData="Audio Context: UnKnow init";
        mVisual.mData="Visual Context: UnKnow init";

       //  getNewData();
    }

    public static MetaContext getInstance() {
       //Double check locking pattern
        if (mMetaContext == null) {  //Check for the first time
            synchronized (MetaContext.class) {   //Check for the second time.
                //if there is no instance available... create new one
                if (mMetaContext == null) mMetaContext = new MetaContext();
            }
        }


        return mMetaContext;
    }

    // Simulate data
    /*public  void getNewData() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                populateData("Simulate data", 102);
            }
        }, 10000);
    }*/

    public void run() {
        int i=0;
        while (true) {
            System.out.println(Thread.currentThread().getName() + "  " + i);
            getNewData(i);
            try {
                Thread.sleep(5000);
                System.out.println("===sleep wake==");
            } catch (InterruptedException e) {
                System.out.println("===cache error ==");
                e.printStackTrace();
            }
            i++;

        }
    }


    public  void getNewData(int i) {

        SyntheticData("Simulate data  getNewData()   #"+i);
    }

    public void SyntheticData(String data) {

      /*  mIOD.mData=data;
        setChanged();   // for push data
        notifyObservers(mIOD);  // for push data*/
    }

    public String pullData() {
        return "****pull data from MetaContext";
    }
    //Make singleton from serialize and deserialize operation.
    protected MetaContext readResolve() {
        return getInstance();
    }

}


