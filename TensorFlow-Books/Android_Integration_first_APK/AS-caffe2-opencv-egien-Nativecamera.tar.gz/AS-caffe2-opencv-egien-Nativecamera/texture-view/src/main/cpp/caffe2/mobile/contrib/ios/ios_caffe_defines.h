// Copyright 2004-present Facebook. All Rights Reserved.

#define IOS_CAFFE_EXPORT __attribute__((visibility("default")))
