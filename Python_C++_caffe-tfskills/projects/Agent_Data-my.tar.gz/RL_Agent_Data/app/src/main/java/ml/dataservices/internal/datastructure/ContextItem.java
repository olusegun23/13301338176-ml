package ml.dataservices.internal.datastructure;

import java.io.Serializable;

import android.icu.util.Calendar;


/**
 * Created by haijunz on 17-10-19.
 */

public class ContextItem implements Serializable {

    public Calendar mCreateTime =  Calendar.getInstance();
    public String   mData="";
    public String toString(){

     return "CreateTime:"+mCreateTime.getTimeInMillis()+","+mData;

    };


}
