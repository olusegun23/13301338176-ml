package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class Touch_Service extends Service implements View.OnTouchListener {

    private static final String TAG = Touch_Service.class.getSimpleName();

     public Touch_Service() {


    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {

               // if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_UP)
           Log.d(TAG, "Action :" + event.getAction() + "\t X :" + event.getRawX() + "\t Y :" + event.getRawY());
           return false;
    }












}
