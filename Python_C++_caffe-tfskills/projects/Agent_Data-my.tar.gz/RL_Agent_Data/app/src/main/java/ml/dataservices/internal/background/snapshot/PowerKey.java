package ml.dataservices.internal.background.snapshot;

import android.icu.util.Calendar;
import android.util.Log;

import ml.dataservices.internal.utils.EXEC;
import ml.dataservices.internal.utils.Globals;


public  class PowerKey {
    private static  String TAG = PowerKey.class.getSimpleName();
    // String last="";
   
     private static State mState = new PowerkeyFreeState(0);
     private static PowerKeyContext mContext = new PowerKeyContext(mState);

    public static void snapshot() {

         String[] ss= new String[]{"/system/bin/sh","-c","cat /proc/interrupts  | grep qpnp_kpdpwr_status"};
         String current = EXEC.do_exec(ss);
         Log.i(TAG, "EXEC return " + Thread.currentThread().getStackTrace()[2] + current);
         mContext.doAction(current);
         Globals g = Globals.getInstance();
         g.metaContext.mPowerKeyInfo.mCreateTime= Calendar.getInstance();
         g.metaContext.mPowerKeyInfo.mData=mContext.getState().toString();
         Log.i(TAG, "State Machine result1" + Thread.currentThread().getStackTrace()[2] + mContext.getState().toString());
          }

}