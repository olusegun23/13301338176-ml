package com.talkingdata.myna;

interface MynaResultInterface {

    /**
     * Method which will be called when error occurs.
     */
    MynaResult getError();
}
