package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import ml.dataservices.internal.background.receivers.Screen_ChangeReceiver;

public class ScreenOnOffUserpresnetUnlock_Service extends Service {
    private static  String TAG = Screen_ChangeReceiver.class.getSimpleName();
    private Screen_ChangeReceiver mScreenReceiver;
    public ScreenOnOffUserpresnetUnlock_Service() {
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        registerScreenStatusReceiver();
    }

    @Override
    public void onDestroy() {
        unregisterScreenStatusReceiver();
    }

    private void registerScreenStatusReceiver() {
        mScreenReceiver = new Screen_ChangeReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        filter.addAction(Intent.ACTION_USER_UNLOCKED);
        registerReceiver(mScreenReceiver, filter);

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    private void unregisterScreenStatusReceiver() {
        try {
            if (mScreenReceiver != null) {
                unregisterReceiver(mScreenReceiver);
            }
        } catch (IllegalArgumentException e) {}

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }
}


