package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.icu.util.TimeZone;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.utils.Globals;

import java.util.Locale;

import static java.lang.Thread.sleep;


public class Time_Service extends Service {


    private static  String TAG = Time_Service.class.getSimpleName();
    Globals g ;
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    public Time_Service() {

    }

    @Override
    public void onCreate() {

        // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+".."+ b);
       // https://developer.android.com/reference/android/app/ActivityManager.RecentTaskInfo.html

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

       // g = (Globals)getApplication();

       /* UserManager userManager = (UserManager)getSystemService(Context.USER_SERVICE);
        UserHandle me = android.os.Process.myUserHandle();
        long serialNumber = userManager.getSerialNumberForUser(me);
     */

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);
               //Creating new thread for my service
        //Always write your long running tasks in a separate thread, to avoid ANR
        new Thread(new Runnable() {

            @Override
            public void run() {
                Globals g = Globals.getInstance();
//               HardwarePropertiesManager hardware = (HardwarePropertiesManager) getSystemService(Context.HARDWARE_PROPERTIES_SERVICE);
                 try {
                    while (g.isRunning) {

                       sleep(g.mServicesSleepTime);
                       // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--cpuTemperature=="+g.metaContext.mCpuItem.mCreateTime.getTimeInMillis());
                        g.metaContext.mTime.mCreateTime  =  Calendar.getInstance();
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"Locate =="+ Locale.getDefault());
                        g.metaContext.mTime.mCreateTime .setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"getTime=="+ g.metaContext.mTime.mCreateTime.getTime());
                        SimpleDateFormat format1 = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+format1.format(g.metaContext.mTime.mCreateTime.getTime()));
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--..hour--"+ g.metaContext.mTime.mCreateTime.get(Calendar.HOUR));
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--day of month--"+ g.metaContext.mTime.mCreateTime.get(Calendar.DAY_OF_MONTH));
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--month::"+(g.metaContext.mTime.mCreateTime.get(Calendar.MONTH)+1));
                        g.metaContext.mTime.mData="hour:"+g.metaContext.mTime.mCreateTime.get(Calendar.HOUR)+","+"day of month:"+g.metaContext.mTime.mCreateTime.get(Calendar.DAY_OF_MONTH)+",month:"+(g.metaContext.mTime.mCreateTime.get(Calendar.MONTH)+1);

                        long currentTime = System.currentTimeMillis();
                            // get usage stats for the last 10 seconds


                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();



        return Service.START_STICKY;
            //return mStartMode;




    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {


        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }





}



