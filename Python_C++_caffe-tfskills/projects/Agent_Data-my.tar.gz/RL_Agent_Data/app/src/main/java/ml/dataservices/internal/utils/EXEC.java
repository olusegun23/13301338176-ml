package ml.dataservices.internal.utils;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by haijunz on 17-11-9.
 */

public class EXEC {

    private static  String TAG = EXEC.class.getSimpleName();

    public final static String COMMAND_SU       = "/system/xbin/su";
    public final static String COMMAND_SH       = "sh";
    public final static String COMMAND_EXIT     = "exit\n";
    public final static String COMMAND_LINE_END = "\n";


    public static class CommandResult {
        public int result = -1;
        public String errorMsg;
        public String successMsg;
    }



    public static CommandResult execCommand(String command, boolean isRoot) {
        String[] commands = {command};
        return execCommand(commands, isRoot);
    }


    public static CommandResult execCommand(String[] commands, boolean isRoot) {
        CommandResult commandResult = new CommandResult();
        if (commands == null || commands.length == 0) return commandResult;
        Process process = null;
        DataOutputStream os = null;
        BufferedReader successResult = null;
        BufferedReader errorResult = null;
        StringBuilder successMsg = null;
        StringBuilder errorMsg = null;

        Log.d(TAG, "XXXX1" + Thread.currentThread().getStackTrace()[2]);

        try {
            process = Runtime.getRuntime().exec(isRoot ? COMMAND_SU : COMMAND_SH);
            os = new DataOutputStream(process.getOutputStream());
            for (String command : commands) {
                if (command != null) {
                    os.write(command.getBytes());
                    os.writeBytes(COMMAND_LINE_END);
                    os.flush();
                }
            }
            Log.d(TAG, "XXXX2" + Thread.currentThread().getStackTrace()[2]);

            os.writeBytes(COMMAND_EXIT);
            os.flush();
           // commandResult.result = process.waitFor();


            Log.d(TAG, "XXXX3" + Thread.currentThread().getStackTrace()[2]);

            successMsg = new StringBuilder();
            errorMsg = new StringBuilder();
            successResult = new BufferedReader(new InputStreamReader(process.getInputStream()));
            errorResult = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            String s;
            //while ((s = successResult.readLine()) != null) successMsg.append(s);

            successMsg.append(successResult.readLine());

            // while ((s = errorResult.readLine()) != null) errorMsg.append(s);

            errorMsg.append(errorResult.readLine());
            commandResult.successMsg = successMsg.toString();
            commandResult.errorMsg = errorMsg.toString();

            Log.d(TAG, "XXXX4" + Thread.currentThread().getStackTrace()[2]+successMsg);

            Log.d(TAG, "XXXX5" + Thread.currentThread().getStackTrace()[2]+errorMsg);

            Log.i(TAG, commandResult.result + " | " + commandResult.successMsg
                    + " | " + commandResult.errorMsg);

        } catch (IOException e) {
            String errmsg = e.getMessage();
            if (errmsg != null) {
                Log.e(TAG, errmsg);
            } else {
                e.printStackTrace();
            }
        } catch (Exception e) {
            String errmsg = e.getMessage();
            if (errmsg != null) {
                Log.e(TAG, errmsg);
            } else {
                e.printStackTrace();
            }
        } finally {
            try {
                if (os != null) os.close();
                if (successResult != null) successResult.close();
                if (errorResult != null) errorResult.close();
            } catch (IOException e) {
                String errmsg = e.getMessage();
                if (errmsg != null) {
                    Log.e(TAG, errmsg);
                } else {
                    e.printStackTrace();
                }
            }
            if (process != null) process.destroy();
        }
        return commandResult;
    }


    public static String do_exec_test() {
       // return ""+ execCommand("/system/bin/getevent",false);
      //  return ""+ execCommand("cat /proc/interrupts  | grep qpnp_kpdpwr_status",false);
        return ""+ execCommand(new String[]{"sh","-c","cat /proc/interrupts"},false);

    }



    public static String do_exec(String cmd) {
        String s = "\n";
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(p.getInputStream()));
            String line = null;
            while ((line = in.readLine()) != null) {
                s += line + "\n";
            }

            Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+s);

        } catch (IOException e) {
            // TODO Auto-generated catch block
            Log.d(TAG, "IOException" + Thread.currentThread().getStackTrace()[2]);

            e.printStackTrace();
        }

        return s;
    }



    public static String do_exec(String[] ss) {

        // adb shell su 0 setenforce permissive
        String s = "\n";
        String e1 = "\n";
        String _s = "\n";
        try {

           // Process p = Runtime.getRuntime().exec(new String[]{"/system/bin/sh","-c","cat /proc/interrupts  | grep qpnp_kpdpwr_status"});
            Process p = Runtime.getRuntime().exec(ss);
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
           String line = null;
           while ((line = in.readLine()) != null) {
                s += line + "\n";
           }

            Log.d(TAG, "getInputStream" + Thread.currentThread().getStackTrace()[2]+s);
            BufferedReader _error = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            String line_err = null;
            while ((line_err= _error.readLine()) != null) {
                e1 += line_err + "\n";
            }

            Log.d(TAG, "getErrorStream" + Thread.currentThread().getStackTrace()[2]+e1);
            in.close();
            _error.close();
            p.destroy();


        } catch (IOException e) {
            // TODO Auto-generated catch block
            Log.d(TAG, "IOException" + Thread.currentThread().getStackTrace()[2]);

            e.printStackTrace();
        }



        return s;
    }







      /* g.metaContext.mDeviceInfo.mCreateTime= Calendar.getInstance();
                        g.metaContext.mDeviceInfo.mData="EVENTs:";


                        // String myExec = "sh settings get system screen_brightnes";
                        StringBuilder result=new StringBuilder();
                        final StringBuilder append = result.append("....");
                        Process process;
                        try {
                            /*process = Runtime.getRuntime().exec("am start -a android.intent.action.MAIN -n com.android.settings/.Settings");
                            process = Runtime.getRuntime().exec("getprop  ro.sf.lcd_density");
                            process = Runtime.getRuntime().exec("cat /sys/class/leds/lcd-backlight/brightness");
                            process = Runtime.getRuntime().exec("cat /sys/class/power_supply/battery/current_now");

             process = Runtime.getRuntime().exec("getevent -l");  */

    /*

                            process.wait();
                            process.waitFor();
    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
    String s = reader.readLine();
                            Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--EVENT11111"+s);

}
                        catch(Exception e) {

                                Log.d(TAG, "Exception  " + Thread.currentThread().getStackTrace()[2]+e);
                                e.printStackTrace();
                                }

                                */

}


/*



top命令如下：
1.  adb shell
2.  $ top -h
3.  top -h
4.  Usage: top [-m max_procs] [-n iterations] [-d delay] [-s sort_column] [-t] [-h]
5.    -m num  Maximum number of processes to display. // 最多显示多少个进程
6.    -n num  Updates to show before exiting. // 刷新次数
7.    -d num  Seconds to wait between updates. // 刷新间隔时间（默认5秒）
8.    -s col  Column to sort by <cpu,vss,rss,thr> // 按哪列排序
9.    -t      Show threads instead of processes. // 显示线程信息而不是进程
10.   -h      Display this help screen. // 显示帮助文档
11. $ top -n 1
12. top -n 1
就不把执行效果放上来了，总之结果表述如下：
1.  User 35%, System 13%, IOW 0%, IRQ 0% // CPU占用率
2.  User 109 + Nice 0 + Sys 40 + Idle 156 + IOW 0 + IRQ 0 + SIRQ 1 = 306 // CPU使用情况
3.
4.  PID CPU% S #THR VSS RSS PCY UID Name // 进程属性
5.  xx  xx% x   xx  xx  xx  xx  xx   xx
6.
7.  CPU占用率：
8.  User    用户进程
9.  System  系统进程
10. IOW IO等待时间
11. IRQ 硬中断时间
12.
13. CPU使用情况（指一个最小时间片内所占时间，单位jiffies。或者指所占进程数）：
14. User    处于用户态的运行时间，不包含优先值为负进程
15. Nice    优先值为负的进程所占用的CPU时间
16. Sys 处于核心态的运行时间
17. Idle    除IO等待时间以外的其它等待时间
18. IOW IO等待时间
19. IRQ 硬中断时间
20. SIRQ    软中断时间
21.
22. 进程属性：
23. PID 进程在系统中的ID
24. CPU%    当前瞬时所以使用CPU占用率
25. S   进程的状态，其中S表示休眠，R表示正在运行，Z表示僵死状态，N表示该进程优先值是负数。
26. #THR    程序当前所用的线程数
27. VSS Virtual Set Size 虚拟耗用内存（包含共享库占用的内存）
28. RSS Resident Set Size 实际使用物理内存（包含共享库占用的内存）
29. PCY OOXX，不知道什么东东
30. UID 运行当前进程的用户id
31. Name    程序名称android.process.media
32.
33. // ps：内存占用大小有如下规律：VSS >= RSS >= PSS >= USS
34. // PSS  Proportional Set Size 实际使用的物理内存（比例分配共享库占用的内存）
35. // USS  Unique Set Size 进程独自占用的物理内存（不包含共享库占用的内存）
在附件Android系统->android top.txt文件内，自个总结的。
2）执行代码

1.  // top命令
2.  public static final String[] TOP = { "/system/bin/top", "-n", "1" };
3.
4.  // 现在执行top -n 1，我们只需要第二行（用第二行求得CPU占用率，精确数据）
5.  // 第一行：User 35%, System 13%, IOW 0%, IRQ 0% // CPU占用率
6.  // 第二行：User 109 + Nice 0 + Sys 40 + Idle 156 + IOW 0 + IRQ 0 + SIRQ 1 = 306
7.  // // CPU使用情况
8.  public static synchronized String run(String[] cmd) {
9.      String line = "";
10.     InputStream is = null;
11.     try {
12.         Runtime runtime = Runtime.getRuntime();
13.         Process proc = runtime.exec(cmd);
14.         is = proc.getInputStream();
15.
16.         // 换成BufferedReader
17.         BufferedReader buf = new BufferedReader(new InputStreamReader(is));
18.         do {
19.             line = buf.readLine();
20.             // 前面有几个空行
21.             if (line.startsWith("User")) {
22.                 // 读到第一行时，我们再读取下一行
23.                 line = buf.readLine();
24.                 break;
25.             }
26.         } while (true);
27.
28.         if (is != null) {
29.             buf.close();
30.             is.close();
31.         }
32.     } catch (IOException e) {
33.         e.printStackTrace();
34.     }
35.     return line;
36. }
37.
38. // 获取指定应用的top命令获取的信息
39. // PID CPU% S #THR VSS RSS PCY UID Name // 进程属性
40. // 如果当前应用不在运行则返回null
41. public static synchronized String run(String[] cmd, String pkgName) {
42.     String line = null;
43.     InputStream is = null;
44.     try {
45.         Runtime runtime = Runtime.getRuntime();
46.         Process proc = runtime.exec(cmd);
47.         is = proc.getInputStream();
48.
49.         // 换成BufferedReader
50.         BufferedReader buf = new BufferedReader(new InputStreamReader(is));
51.         do {
52.             line = buf.readLine();
53.             // 读取到相应pkgName跳出循环（或者未找到）
54.             if (null == line || line.endsWith(pkgName)) {
55.                 break;
56.             }
57.         } while (true);
58.
59.         if (is != null) {
60.             buf.close();
61.             is.close();
62.         }
63.     } catch (IOException e) {
64.         e.printStackTrace();
65.     }
66.     return line;
67. }

















 */