package ml.dataservices.internal.background.accessibility;

import android.accessibilityservice.AccessibilityService;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import ml.dataservices.internal.utils.PrintEventUtils;




public class Behavior_Service extends AccessibilityService {


    private static  String TAG = Behavior_Service.class.getSimpleName();
    @Override
    public boolean onKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();

        /*if (action == KeyEvent.ACTION_UP) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                Log.d("Hello", "KeyUp");
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                Log.d("Hello", "KeyDown");
            }
            return true;
        } else {
            return super.onKeyEvent(event);
            } */

        if (action == KeyEvent.ACTION_UP) {

            if (keyCode == KeyEvent.KEYCODE_POWER) {
                Log.d(TAG, "onKeyEvent" + Thread.currentThread().getStackTrace()[2]+"..KEYCODE_POWER" +
                        ".....");

            }
        }


        Log.d(TAG, "onKeyEvent" + Thread.currentThread().getStackTrace()[2]+event);
        Log.d(TAG, "onKeyEvent" + Thread.currentThread().getStackTrace()[2]+event);
        Log.d(TAG, "onKeyEvent" + Thread.currentThread().getStackTrace()[2]+event.getCharacters());

        return true;

    }



    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        PrintEventUtils.printEvent(event);
    }


    @Override
    public void onInterrupt() {
        PrintEventUtils.log("onInterrupt");
    }

    @Override
    protected boolean onGesture(int gestureId) {
        PrintEventUtils.log("onGesture");
        return super.onGesture(gestureId);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        PrintEventUtils.log("onServiceConnected");
//        //可用代码配置当前Service的信息
//        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
//        info.packageNames = new String[]{"com.android.packageinstaller", "com.tencent.mobileqq", "com.trs.gygdapp"}; //监听过滤的包名
//        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK; //监听哪些行为
//        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_SPOKEN; //反馈
//        info.notificationTimeout = 100; //通知的时间
//        setServiceInfo(info);
    }


}
