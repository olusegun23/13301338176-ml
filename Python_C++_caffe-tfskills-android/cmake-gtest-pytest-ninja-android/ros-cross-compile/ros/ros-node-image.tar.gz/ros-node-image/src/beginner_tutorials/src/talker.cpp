#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>


#include <vector>
#include <random>
#include <climits>
#include <algorithm>
#include <functional>
#include <iostream>
using random_bytes_engine = std::independent_bits_engine<std::default_random_engine, CHAR_BIT, unsigned char>;





int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_publisher");
  ros::NodeHandle nh;
  image_transport::ImageTransport it(nh);
  image_transport::Publisher pub = it.advertise("camera/image", 1);



  //cv::Mat image = cv::imread(argv[1], CV_LOAD_IMAGE_COLOR);
  //cv::waitKey(30);


//  sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", mat).toImageMsg();

 ros::Rate loop_rate(5);
  while (nh.ok()) {

std::vector<unsigned char> data(640*480);
 cv::Mat mat(640,480,CV_8UC1);

random_bytes_engine rbe;
std::generate(begin(data), end(data), std::ref(rbe));
data.assign(mat.data,mat.data+640*480);
//sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", mat).toImageMsg();	
sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "mono8", mat).toImageMsg();

    pub.publish(msg);
    ros::spinOnce();
    loop_rate.sleep();
  }
}
