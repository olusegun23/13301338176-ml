/*==============================================================================
  Copyright (c) 2015 Qualcomm Technologies, Inc.
  All rights reserved. Qualcomm Proprietary and Confidential.
==============================================================================*/

#include <stdint.h>
#include <stdio.h>

#include <semaphore.h>

#include "test_utils.h"
#include "dspal_tester.h"

/**
* @brief Tests semaphore functionality (using 1 thread)
* 
* @par Test:
* 1) Initialize the semaphore to a value of 0
* 2) Get the value of the semaphore and check that is 0
* 3) Do a try wait and make sure it returns an error (needs to error out because no post yet)
* 4) Do a semaphore post
* 5) Get the value of the semaphore and make sure it is 1 (set to 1 from step 4)
* 6) Do a wait on the semaphore
* 7) Get the value of the semaphore and make sure it is 0, 9 set to 1 from step 4 and 0 from step 6)
* 8) Destroy the Semaphore
*
* @return
* TEST_PASS ------ Always
*/
int dspal_tester_test_semaphore_wait(void)
{
   int rv = 0;

   int sem_value = 0;
   sem_t sem;

   rv = sem_init(&sem, 0, 0);
   if (rv != 0) FAIL("sem_init returned error");

   rv = sem_getvalue(&sem, &sem_value);
   if (rv != 0) FAIL("sem_getvalue returned error");
   if (sem_value != 0) FAIL("sem_value not as expected");

   rv = sem_trywait(&sem);
   if (rv != -1) FAIL("sem_trywait DID NOT return an error");

   rv = sem_post(&sem);
   if (rv != 0) FAIL("sem_post returned error");

   rv = sem_getvalue(&sem, &sem_value);
   if (rv != 0) FAIL("sem_getvalue returned error");
   if (sem_value != 1) FAIL("sem_value not as expected");

   rv = sem_wait(&sem);
   if (rv != 0) FAIL("sem_wait returned error");

   rv = sem_getvalue(&sem, &sem_value);
   if (rv != 0) FAIL("sem_getvalue returned error");
   if (sem_value != 0) FAIL("sem_value not as expected");

   rv = sem_destroy(&sem);
   if (rv != 0) FAIL("sem_destroy returned error");

   return TEST_PASS;
}
