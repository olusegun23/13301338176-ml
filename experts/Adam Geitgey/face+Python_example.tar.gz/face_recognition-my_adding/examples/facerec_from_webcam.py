import face_recognition
import cv2

# This is a super simple (but slow) example of running face recognition on live video from your webcam.
# There's a second example that's a little more complicated but runs faster.

# PLEASE NOTE: This example requires OpenCV (the `cv2` library) to be installed only to read from your webcam.
# OpenCV is *not* required to use the face_recognition library. It's only required if you want to run this
# specific demo. If you have trouble installing it, try any of the other demos that don't require it instead.

# Get a reference to webcam #0 (the default one)
video_capture = cv2.VideoCapture(0)

# Load a sample picture and learn how to recognize it.
zhj_image = face_recognition.load_image_file("zhj1.jpg")
zhj_face_encoding = face_recognition.face_encodings(zhj_image)[0]

obama_image = face_recognition.load_image_file("hero.jpg")
obama_face_encoding = face_recognition.face_encodings(obama_image)[0]

unknow_image = face_recognition.load_image_file("biden.jpg")
unknow_face_encoding = face_recognition.face_encodings(unknow_image)[0]






while True:
    # Grab a single frame of video




    ret, frame = video_capture.read()

    # Resize frame of video to 1/4 size for faster face recognition processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)



    # Find all the faces and face enqcodings in the frame of video
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)



    face_landmarks_list = face_recognition.face_landmarks(frame)

    print  face_landmarks_list

    for face_landmarks in face_landmarks_list:
        print (face_landmarks)
        for (points) in face_landmarks.values():
            for (x, y) in points:
                cv2.circle(frame, (x, y), 1, (0,255,0), -1)





    # Loop through each face in this frame of video
    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        # See if the face is a match for the known face(s)
        known_faces = [obama_face_encoding,zhj_face_encoding]
        #results = face_recognition.compare_faces([obama_face_encoding,zhj_face_encoding], face_encodings)
        results = face_recognition.compare_faces([obama_face_encoding,zhj_face_encoding], face_encoding, tolerance=0.3)
        labels = ['hero', 'Haijun Zhao']
        name =    "Unknown..not in DB"


        print('results==(1)======:' + str(results))


        for i in range(0, len(results)):
            if results[i] == True:
                print('     The person is:' + labels[i])
                name = labels[i]

        print('results==(2)======:' + str(results))


        # Draw a box around the face
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        # Draw a label with a name below the face
        #cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), 2)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)
        #cv2.line(face_landmarks[facial_features])
        #cv2.polylines(face_landmarks[facial_features])




    # Display the resulting image
    cv2.imshow('Video', frame)

    # Hit 'q' on the keyboard to quit!
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release handle to the webcam
video_capture.release()
cv2.destroyAllWindows()
