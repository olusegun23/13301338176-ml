package ml.dataservices.internal.background.accessibility;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.icu.util.Calendar;

import ml.dataservices.internal.datastructure.MetaContext;
import ml.dataservices.internal.utils.Globals;

import static java.lang.Thread.sleep;


public class ForegroundApp_Service extends AccessibilityService {
    private static  String TAG = ForegroundApp_Service.class.getSimpleName();

    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used
    Globals g=Globals.getInstance();


    @Override
    public boolean onKeyEvent(KeyEvent event) {

        Log.d(TAG, "onKeyEvent" + Thread.currentThread().getStackTrace()[2]+event);
        int action = event.getAction();
        int keyCode = event.getKeyCode();

        /*if (action == KeyEvent.ACTION_UP) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                Log.d("Hello", "KeyUp");
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                Log.d("Hello", "KeyDown");
            }
            return true;
        } else {
            return super.onKeyEvent(event);
            } */

        if (action == KeyEvent.ACTION_UP) {

            if (keyCode == KeyEvent.KEYCODE_POWER) {
                Log.d(TAG, "onKeyEvent" + Thread.currentThread().getStackTrace()[2]+"..KEYCODE_POWER" +
                        ".....");

            }
        }

        return super.onKeyEvent(event);

    }


    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "onServiceConnected" + Thread.currentThread().getStackTrace()[2]);
/*       g = (Globals)getApplication();
        g.metaContext= MetaContext.getInstance();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.flags = AccessibilityServiceInfo.DEFAULT;
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        setServiceInfo(info);*/


        Log.v(TAG, "on Service Connected");

    }
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        Log.v(TAG, String.format( "onAccessibilityEvent: [type] %s [class] %s [package] %s [time] %s [text] %s", getEventType(event), event.getClassName(), event.getPackageName(),event.getEventTime(), getEventText(event)));
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--event"+event);
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--getText=="+event.getText());
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--toString"+event.toString());
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--describeContent=="+event.describeContents());
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--getAction"+event.getAction());
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--getContentChangeTypes=="+event.getContentChangeTypes());
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--eventType=="+event.getEventType());
        /*String pkgName = event.getPackageName().toString();
        String eventText = null;
        switch(eventType) {
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                eventText = "Focused: ";
                break;
            case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                eventText = "Focused: ";
                break;
        }
        eventText = eventText + event.getContentDescription();
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--pkgName=="+pkgName);
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--eventType=="+eventType);
        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--eventText=="+eventText);
*/

        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            ComponentName componentName = new ComponentName(
                    event.getPackageName().toString(),
                    event.getClassName().toString()
            );

            ActivityInfo activityInfo = tryGetActivity(componentName);
            boolean isActivity = activityInfo != null;
            if (isActivity)

                g = Globals.getInstance();
                g.metaContext= MetaContext.getInstance();
                g.metaContext.mAppInfo.mCreateTime=Calendar.getInstance();
                g.metaContext.mAppInfo.mData="ForegroundApp:"+componentName.flattenToShortString();
                Log.d(TAG,"CurrentActivity  "+ componentName.flattenToShortString());

        }


        if (event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START) {


            Log.d(TAG,"TYPE_TOUCH_INTERACTION_START ");

        }

    }


    @Override
    public void onInterrupt() {

    }



    private ActivityInfo tryGetActivity(ComponentName componentName) {
        try {
            return getPackageManager().getActivityInfo(componentName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }




    private String getEventType(AccessibilityEvent event) {
        switch (event.getEventType()) {
            case AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED:
                return "TYPE_NOTIFICATION_STATE_CHANGED";
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                return "TYPE_VIEW_CLICKED";
            case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                return "TYPE_VIEW_FOCUSED";
            case AccessibilityEvent.TYPE_VIEW_LONG_CLICKED:
                return "TYPE_VIEW_LONG_CLICKED";
            case AccessibilityEvent.TYPE_VIEW_SELECTED:
                return "TYPE_VIEW_SELECTED";
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                return "TYPE_WINDOW_STATE_CHANGED";
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                return "TYPE_VIEW_TEXT_CHANGED";
        }
        return "default";
    }




    private String getEventText(AccessibilityEvent event) {
        StringBuilder sb = new StringBuilder();
        for (CharSequence s : event.getText()) {
            sb.append(s);
        }
        return sb.toString();
    }


}



