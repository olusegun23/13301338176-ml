package ml.dataservices.internal.background.services;

import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.IBinder;
import android.os.health.SystemHealthManager;
import android.service.vr.VrListenerService;
import android.util.Log;

import ml.dataservices.internal.utils.Globals;

import static java.lang.Thread.sleep;

public class VR_Service_HW extends VrListenerService {

    private static  String TAG = VR_Service_HW.class.getSimpleName();
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used


    public VR_Service_HW() {
    }



    @Override
    public void onCreate() {

        // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+".."+ b);
        // https://developer.android.com/reference/android/app/ActivityManager.RecentTaskInfo.html

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);


        /*final DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if(!dpm.isDeviceOwnerApp(getPackageName()))
        {
            Log.i(TAG, "====" + Thread.currentThread().getStackTrace()[2]+"App is not device owner, set it with `dpm set-device-owner it.denv.hwmonitor/.AdmRcvr` by adb shell and restart the app");

        }*/

        DevicePolicyManager policyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);

      /*     crash
        ComponentName adminReceiver = new ComponentName(getApplicationContext(),ScreenAdminReceiver.class);
        boolean admin = policyManager.isAdminActive(adminReceiver);
        if (admin) {
            HardwarePropertiesManager hwpm = (HardwarePropertiesManager) getSystemService(this.HARDWARE_PROPERTIES_SERVICE);
            CpuUsageInfo cpuUsage[] = hwpm.getCpuUsages();
            Log.i(TAG, "====" + Thread.currentThread().getStackTrace()[2]+"length: %d  "+cpuUsage.length);

            for (CpuUsageInfo coreUsage : cpuUsage)
            {
                String cpu_tmp = String.format("%d / %d", coreUsage.getActive(), coreUsage.getTotal());
                Log.i(TAG,"cpu_tmp"+cpu_tmp);

            }


        } else {


            Log.i(TAG, "Not an admin");
        }



    */

        //Creating new thread for my service
        //Always write your long running tasks in a separate thread, to avoid ANR
        new Thread(new Runnable() {

            @Override
            public void run() {

                Globals g = Globals.getInstance();

                SystemHealthManager h=  (SystemHealthManager) getSystemService(SYSTEM_HEALTH_SERVICE);

                 try {
                    while (g.isRunning) {

                        sleep(g.mServicesSleepTime);
                        // SCREEN_OFF_TIMEOUT   SOUND_EFFECTS_ENABLED  VIBRATE_ON VIBRATE_WHEN_RINGING
                        int curBrightnessValue = android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS,-1);
                        g.metaContext.mDeviceInfo.mCreateTime= Calendar.getInstance();
                        g.metaContext.mDeviceInfo.mData="LCD_Brightness:"+curBrightnessValue;
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+":"+h.takeMyUidSnapshot());
                        // float[] cpuTemperature = s.getDeviceTemperatures(HardwarePropertiesManager.DEVICE_TEMPERATURE_CPU, HardwarePropertiesManager.TEMPERATURE_CURRENT);

                        //Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+":"+s.getDeviceTemperatures(1,1));
                         //Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"   "+s.getFanSpeeds());
                        //Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+" getCpuUsages  "+s.getCpuUsages());

                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }




            }
        }).start();



        return Service.START_STICKY;
        //return mStartMode;




    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {


        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }



















}
