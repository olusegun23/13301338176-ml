### An Android Album Application which uses tensorflow to classify the images

update @ 20170107: Application can run successfully， by which you can browse photos and uses tf to classify photos on your Android phone; but there are still some bugs need to be fixed 


update @ 20161229 by dongchangzhang

INFO:
 * only can run on x86_64 or armeabi-v7a emulator
 * use your own classify images model which is needed to be dealed by strip_unused.py in tensorflow/python/tools



