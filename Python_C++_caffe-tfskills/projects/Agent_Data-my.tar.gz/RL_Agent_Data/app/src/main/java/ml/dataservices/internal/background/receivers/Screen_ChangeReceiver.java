package ml.dataservices.internal.background.receivers;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.IBinder;
import android.util.Log;

import ml.dataservices.internal.utils.Globals;


/**
 * Created by haijunz on 17-11-6.
 */

public class Screen_ChangeReceiver extends BroadcastReceiver  {


    private static  String TAG = Screen_ChangeReceiver.class.getSimpleName();

    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used

    @Override
    public void onReceive(Context context, Intent intent) {

       // g = (Globals)getApplication();
//        g.metaContext= MetaContext.getInstance();

        String action = intent.getAction();
        Log.d(TAG, ""+action);

        Log.d(TAG, ""+context.getPackageCodePath());
        Log.d(TAG, ""+context.getPackageName());
        Log.d(TAG, ""+context.getPackageResourcePath());
        Log.d(TAG, ""+context.toString());
        Log.d(TAG, ""+context.getApplicationContext());
        Log.d(TAG, ""+context.getApplicationInfo());









        Globals g = Globals.getInstance();
        g.metaContext.mScreenInfo.mCreateTime= Calendar.getInstance();

        if(Intent.ACTION_SCREEN_ON.equals(action))
        {
            g.metaContext.mScreenInfo.mData="Screen_Info:"+"ON";
            Log.d(TAG, "zhj-screen is on...");

        }
        else if(Intent.ACTION_SCREEN_OFF.equals(action))
        {
            g.metaContext.mScreenInfo.mData="Screen_Info:"+"OFF";
            Log.d(TAG, "zhj-screen is off...");
        }
        else if(Intent.ACTION_USER_PRESENT.equals(action))
        {
            Log.d(TAG, "zhj-screen is unlock...");
        }

    }

    /*public IntentFilter getFilter(){
        final IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        return filter;
    }*/




}
