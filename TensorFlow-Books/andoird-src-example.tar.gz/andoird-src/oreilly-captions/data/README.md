#Import necessary data files
Add caption data, image embeddings, and a vgg16 model as instructued in `../README.md`
