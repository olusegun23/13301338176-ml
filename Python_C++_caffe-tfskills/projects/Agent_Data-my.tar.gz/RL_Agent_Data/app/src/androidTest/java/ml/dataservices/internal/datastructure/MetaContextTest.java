package ml.dataservices.internal.datastructure;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by haijunz on 17-10-19.
 */
public class MetaContextTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void getInstance() throws Exception {

    }

    @Test
    public void readResolve() throws Exception {

    }

    @Test
    public void addCreator() throws Exception {

    }

}