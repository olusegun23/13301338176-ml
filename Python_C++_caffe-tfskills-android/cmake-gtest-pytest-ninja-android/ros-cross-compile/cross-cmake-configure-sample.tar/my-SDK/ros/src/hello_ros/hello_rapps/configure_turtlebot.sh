export TURTLEBOT_RAPP_PACKAGE_WHITELIST="[rocon_apps, turtlebot_rapps, hello_rapps]"
export TURTLEBOT_INTERACTIONS_LIST="[turtlebot_bringup/admin.interactions, turtlebot_bringup/documentation.interactions, turtlebot_bringup/pairing.interactions, turtlebot_bringup/visualisation.interactions, hello_rapps/my.interactions]"

