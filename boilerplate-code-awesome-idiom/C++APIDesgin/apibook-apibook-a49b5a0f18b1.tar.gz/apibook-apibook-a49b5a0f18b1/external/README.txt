This directory contains a subset of the Boost 1.42 includes, used by
some of the source code examples. For the complete Boost package, see
http://www.boost.org/.
