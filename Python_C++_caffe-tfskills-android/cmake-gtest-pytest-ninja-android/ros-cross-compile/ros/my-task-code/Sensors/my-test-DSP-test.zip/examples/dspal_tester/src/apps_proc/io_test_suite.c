/*==============================================================================
 Copyright (c) 2015 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/

#include <stdio.h>
#include "dspal_tester.h"
#include "test_utils.h"

int run_io_test_suite(void)
{
   int test_results = TEST_PASS;

   MSG("testing device path access\n");
  /* test_results |= display_test_results(dspal_tester_spi_test(), "spi loopback test");

   test_results |= display_test_results(dspal_tester_serial_test(), "serial I/O test");*/

  
   MSG(" AP serial I/O test\n");
   test_results |= display_test_results(dspal_tester_i2c_test(), "i2c test");

   test_results |= display_test_results(dspal_tester_serial_test(), "serial I/O test");

   MSG("AP testing GPIO\n");
  // test_results |= display_test_results(dspal_tester_test_gpio_open_close(), "gpio open/close test");
   //test_results |= display_test_results(dspal_tester_test_gpio_ioctl_io(), "gpio ioctl I/O mode test");
  // test_results |= display_test_results(dspal_tester_test_gpio_read_write(), "gpio read/write test");
  // test_results |= display_test_results(dspal_tester_test_gpio_int(), "gpio INT test");

   MSG("AP testing file I/O\n");
   /*test_results |= display_test_results(dspal_tester_test_posix_file_open_close(), "file open/close");
   test_results |= display_test_results(dspal_tester_test_posix_file_read_write(), "file read/write");
   test_results |= display_test_results(dspal_tester_test_posix_file_open_trunc(), "file open_trunc");
   test_results |= display_test_results(dspal_tester_test_posix_file_open_append(), "file open_append");
   test_results |= display_test_results(dspal_tester_test_posix_file_ioctl(), "file ioctl");
   test_results |= display_test_results(dspal_tester_test_posix_file_fsync(), "file fsync");
   test_results |= display_test_results(dspal_tester_test_posix_file_remove(), "file remove");
   test_results |= display_test_results(dspal_tester_test_fopen_fclose(), "fopen/fclose test");
   test_results |= display_test_results(dspal_tester_test_fwrite_fread(), "fwrite/fread test");
   */
   return test_results;
}

