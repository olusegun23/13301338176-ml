package ml.dataservices.internal.background.services;

import android.Manifest;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

public class Location_Service extends Service   {

    private static final String TAG = Location_Service.class.getSimpleName();

    private LocationManager mLocationManager = null;
    private LocationListenerImpl mLocationListener=null;


    String mProvider;
    Location mLocation; // location

    // flag for GPS statusLocationListener
    boolean isGPSEnabled = false;
    // flag for network status
    boolean isNetworkEnabled = false;
    // flag for GPS status
    boolean canGetLocation = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        try {
            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"Start ");

             mLocationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
             mLocationListener=new LocationListenerImpl();
             int  status1 = getPackageManager().checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION,getPackageName());
             int  status2 = getPackageManager().checkPermission(Manifest.permission.ACCESS_FINE_LOCATION,getPackageName());
            // broken mLoction as NUll :   mLocation = mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,  mLocationListener);
             Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " requestLocationUpdates:  " );


            /*if ((status1 == PackageManager.PERMISSION_GRANTED) && (status2 == PackageManager.PERMISSION_GRANTED)) {
                mLocation = mLocationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " LocationManager.PASSIVE_PROVIDER:  " + mLocation.toString());
                mLocation = mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " LocationManager.GPS_PROVIDER:  " + mLocation.toString());

            } else {

                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " LocationManager: Permission error " );
            }*/

            // getting GPS status

            /* isGPSEnabled = mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

            // getting network status
            isNetworkEnabled = mLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

            if (!isGPSEnabled && !isNetworkEnabled) {
                // no network provider is enabled
            } else {
                this.canGetLocation = true;
                // First get location from Network Provider
                if (isNetworkEnabled) {
                    mProvider = LocationManager.NETWORK_PROVIDER;
                    int  status = getPackageManager().checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION,getPackageName());
                    if (status == PackageManager.PERMISSION_GRANTED) {
                        mLocation =mLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+" LocationManager.NETWORK_PROVIDER:  "+mLocation.toString());
                    }

                if (isGPSEnabled) {
                    mProvider = LocationManager.GPS_PROVIDER;
                        mLocation =mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+" LocationManager.GPS_PROVIDER:  "+mLocation.toString());

                }

            }
*/

            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"End ");

        } catch (Exception e) {

            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+e);

        }

        return START_STICKY;


    }


    /**
     * Stop using GPS listener
     * Calling this function will stop using GPS in your app
     * */

   /* public void stopUsingGPS(){
        if(mLocationManager != null){
            mLocationManager.removeUpdates(Location_Service.this);
        }
    }*/


    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }


     static final class  LocationListenerImpl implements LocationListener{


        @Override
        public void onLocationChanged(Location location) {

            if (location!=null) {
                Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + " onLocationChanged:  " + location.toString());
            }

        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

    }


}