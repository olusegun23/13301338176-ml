package ml.dataservices.internal.background.snapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by haijunz on 17-11-14.
 */

public class PowerKeyContext {

    public  State state;

    public PowerKeyContext(State s){
        state = s;
    }

    public void doAction(String current) {

       /*177:          4          0          0          0  qpnp-int  64  qpnp_kpdpwr_status
        177:          5          0          0          0  qpnp-int  64  qpnp_kpdpwr_status
*/
        Matcher m = Pattern.compile("\\d+").matcher(current);
        List<Integer> numbers = new ArrayList<Integer>();
        while (m.find()) {
            numbers.add(Integer.parseInt(m.group()));
        }

        if (state.last> 0) {
            state.doAction(this, numbers.get(1));

        } else {

            // first time run
            state.last=numbers.get(1);

        }

         state.last=numbers.get(1);   // only dump state once;


    }


    public void setState(State state){
        this.state = state;
    }

    public State getState(){
        return state;
    }

}
