package ml.dataservices.internal.background.snapshot;

import android.util.Log;

/**
 * Created by haijunz on 17-11-14.
 */

public class PowerkeyPressState extends State {
    private static String TAG = PowerkeyPressState.class.getSimpleName();

    PowerkeyPressState(int current) {
        last = current;

    }

    public void doAction(PowerKeyContext context, int current) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + "  current is :" + current);
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2] + "  last is :" + last);
    if (current == this.last) {
            context.setState(new PowerkeyFreeState(current));
        }




    }

    public String toString() {

        return ("PowerKey:Press");
    }

}