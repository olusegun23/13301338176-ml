package ml.dataservices.internal.utils;

import android.app.Application;

/**
 * Created by haijunz on 17-11-7.
 */

public class Globals2 extends Application {
}
