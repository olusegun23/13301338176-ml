package ml.dataservices;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.Assert.assertEquals;

/**
 * Created by haijunz on 17-11-14.
 */

public class Test_extract_int_from_string {

    @Test
    public void parse_isCorrect() throws Exception {

        String s = " 177:          5          0          0          0  qpnp-int  64  qpnp_kpdpwr_status";
        Matcher m = Pattern.compile("\\d+").matcher(s);
        List<Integer> numbers = new ArrayList<Integer>();
        while(m.find()) {
            numbers.add(Integer.parseInt(m.group()));
        }
        System.out.println(numbers.get(1));


        assertEquals(4, 2 + 2);
    }


    @Test
    public void parse_DPC() throws Exception {

        String s = "DPC_state:1,DPC_CurrentStateProb:0.0";

        Matcher m = Pattern.compile("\\d+").matcher(s.substring(0,18));
        List<Integer> numbers = new ArrayList<Integer>();
        while(m.find()) {
            numbers.add(Integer.parseInt(m.group()));
        }

        System.out.println(numbers.get(0));

        

       Matcher m1 = Pattern.compile("\\d+").matcher(s.substring(18));
        List<Float> numbers1 = new ArrayList<Float>();
        while(m1.find()) {
            numbers1.add(Float.parseFloat(m1.group()));
        }
        System.out.println(numbers1.get(0));


        assertEquals(4, 2 + 2);
    }





}
