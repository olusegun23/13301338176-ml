package hitcs.fghz.org.album.view;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by me on 17-1-3.
 */

public class MovieShowActivity extends AppCompatActivity {

}

