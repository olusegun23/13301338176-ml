package ml.dataservices.internal.background.services;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Camera;
import android.graphics.SurfaceTexture;
import android.media.MediaRecorder;
import android.os.IBinder;
import android.support.annotation.Nullable;

import android.util.Log;
import android.view.TextureView;

import java.io.IOException;

import ml.dataservices.internal.utils.Globals;

import static java.lang.Thread.sleep;

public class Visual_Service extends Service  {



    private static  String TAG = Visual_Service.class.getSimpleName();

    private SurfaceTexture mSurfaceTexture= new SurfaceTexture(10);
    private Camera mCamera = null;


    public Visual_Service() {
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);





        new Thread(new Runnable() {

            @Override
            public void run() {

                Globals g = Globals.getInstance();

                try {
                    while (g.isRunning) {
                        sleep(g.mServicesSleepTime);



//                      Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--LCD=="+curBrightnessValue);




                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }




            }
        }).start();



        return Service.START_STICKY;
        //return mStartMode;


    }



    @Override
    public void onDestroy() {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }






}










