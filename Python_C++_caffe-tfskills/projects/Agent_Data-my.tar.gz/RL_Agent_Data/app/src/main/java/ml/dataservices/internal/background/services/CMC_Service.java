    package ml.dataservices.internal.background.services;

    import android.app.Service;
    import android.content.Intent;
    import android.hardware.Sensor;
    import android.hardware.SensorEvent;
    import android.hardware.SensorEventListener;
    import android.hardware.SensorManager;
    import android.icu.util.Calendar;
    import android.os.IBinder;
    import android.util.Log;

    import ml.dataservices.internal.utils.Globals;


    /**
     * for a background service not linked to an activity it's important to use the command approach
     * instead of the Binder. For starting use the alarm manager
     */

    public class CMC_Service extends Service   {


        /**
         * a tag for logging
         */
        private static final String TAG = CMC_Service.class.getSimpleName();


        /**
         * again we need the sensor manager and sensor reference
         */
        private SensorManager mSensorManager = null;
        private CMCEventListenerImpl mCMCEventListener=null;






        /**
         * an optional flag for logging
         */

        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {


            Log.d(TAG, "##########received sensor valures are################");

            mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            mCMCEventListener = new CMCEventListenerImpl("QCOM-CMC");

            mSensorManager.registerListener(mCMCEventListener, mSensorManager.getDefaultSensor(33171012), SensorManager.SENSOR_DELAY_UI);

            Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);


                return START_STICKY;
            }



        @Override
        public IBinder onBind(Intent intent) {
            // ignore this since not linked to an activity
            return null;
        }




      /*  @Override
        public void onSensorChanged(SensorEvent event) {

            // for recording of data use an AsyncTask, we just need to compare some values so no
            // background stuff needed for this

            // Log that information for so we can track it in the console (for production code remove
            // this since this will take a lot of resources!!)
            if (mLogging) {

                // grab the values
                StringBuilder sb = new StringBuilder();
                for (float value : event.values)
                    sb.append(String.valueOf(value)).append(" | ");

                Log.d(TAG, "received sensor valures are: ***************** " + sb.toString()+ " and previosValue was: "+previousValue);
            }

            // get the value
            // TODO we could make the value index also configurable, make it simple for now
            float sensorValue = event.values[0];

            // if first value is below min or above max threshold but only when configured
            // we need to enable the screen
            if ((previousValue > mThresholdMin && sensorValue < mThresholdMin)
                    || (previousValue < mThresholdMax && sensorValue > mThresholdMax)) {

                // and a check in between that there should have been a non triggering value before
                // we can mark a given value as trigger. This is to overcome unneeded wakeups during
                // night for instance where the sensor readings for a light sensor would always be below
                // the threshold needed for day time use.

                // TODO we could even make the actions configurable...

                // wake screen here
               PowerManager pm = (PowerManager) getApplicationContext().getSystemService(getApplicationContext().POWER_SERVICE);
                PowerManager.WakeLock wakeLock = pm.newWakeLock((PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP), TAG);
                wakeLock.acquire();

                //and release again
                wakeLock.release();

                // optional to release screen lock
                //KeyguardManager keyguardManager = (KeyguardManager) getApplicationContext().getSystemService(getApplicationContext().KEYGUARD_SERVICE);
                //KeyguardManager.KeyguardLock keyguardLock =  keyguardManager.newKeyguardLock(TAG);
                //keyguardLock.disableKeyguard();
            }

            previousValue = sensorValue;

            // stop the sensor and service
            mSensorManager.unregisterListener(this);
            stopSelf();
        }

*/





        static final class CMCEventListenerImpl implements SensorEventListener {

            private int mCMCState=0;
            private float mCurrentStateProb;

            public CMCEventListenerImpl(String title) {


            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {



            }


            @Override
            public void onSensorChanged(SensorEvent event) {
                final long eventTimeStamp = event.timestamp;
                mCMCState = (int) event.values[0];
                mCurrentStateProb = (float) event.values[1];
                Globals g = Globals.getInstance();
                g.metaContext.mCMC.mCreateTime= Calendar.getInstance();
                g.metaContext.mCMC.mData="CMC_state:"+mCMCState+ ","+"CMC_CurrentStateProb:"+mCurrentStateProb;
                Log.v(TAG, "Event received: "+ "CMC=" + mCMCState+ " CurrentStateProb="+mCurrentStateProb);

                // Tell the listener.

            }









        }






    }
