package ml.dataservices.internal.datastructure;

import junit.framework.Assert;
import junit.framework.TestCase;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.Observable;
import java.util.Observer;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */


public class MetaContextUnitTest extends TestCase implements Observer {
    private MetaContext one = null, two = null;

    public MetaContextUnitTest(String name) {
        super(name);
    }

    public void setUp() {

        System.out.println("Start Test");

        one = MetaContext.getInstance();
        two = MetaContext.getInstance();


    }

    public void testUnique() {

        Assert.assertEquals(true, one == two);
    }


    public void testThreadSafeMetaContext() {

        //Thread 1
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                MetaContext instance1 = MetaContext.getInstance();
                System.out.println("Instance 1 hash:" + instance1.hashCode());
            }
        });

        //Thread 2
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                MetaContext instance2 = MetaContext.getInstance();
                System.out.println("Instance 2 hash:" + instance2.hashCode());
            }
        });

        //start both the threads
        t1.start();
        t2.start();
    }




    public void testSerialization() {


        try {
            MetaContext instance1 = MetaContext.getInstance();
            ObjectOutput out = null;

            out = new ObjectOutputStream(new FileOutputStream("filename.ser"));
            out.writeObject(instance1);
            out.close();

            //deserialize from file to object
            ObjectInput in = new ObjectInputStream(new FileInputStream("filename.ser"));
            MetaContext instance2 = (MetaContext) in.readObject();
            in.close();

            System.out.println("instance1 hashCode=" + instance1.hashCode());
            System.out.println("instance2 hashCode=" + instance2.hashCode());

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public void testObserver() {


        one.mBatteryInfo.mData="ddd";
        Assert.assertEquals(true, "ddd" == one.mBatteryInfo.mData);
        //one.mIOD.mData = "indoor";
        //Assert.assertEquals(true, "indoor" == one.mIOD.mData);

        one.addObserver(this);
        two.addObserver(new Observer() {
            public void update(Observable obj, Object arg) {
                System.out.println("(Two) Received response: " + arg.toString());
            }
        });

        Thread t2=new Thread(two);
        Thread t1= new Thread(one);
        t1.start();
        t2.start();

         // test push
      //  System.out.println("test pullData()" +one.pullData());  // test pull



        while (true) {
            try {
                t1.join();
                t2.join();
                break;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }

    }
    @Override
    public void update(Observable observable, Object o) {
        if (observable instanceof MetaContext) {
            MetaContext a = (MetaContext) observable;
            System.out.println("(One) observable notify......" );
        }
    }





}



