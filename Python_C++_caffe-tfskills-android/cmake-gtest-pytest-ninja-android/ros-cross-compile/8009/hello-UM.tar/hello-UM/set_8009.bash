export PATH=$PATH:/opt/cmake-3.4.3-Linux-x86_64/bin
#export APQ8009_LEUM_ROOT=/prj/atlanticus/releases/8009/LE.UM.0.0_040617_robot/cross-compile-toolchain
