package ml.dataservices.internal.background.services;

import android.app.Service;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.IBinder;
import android.util.Log;
import ml.dataservices.internal.utils.Globals;
import static java.lang.Thread.sleep;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import static java.lang.Thread.sleep;


public class Event_Service extends Service {


    private static  String TAG = Event_Service.class.getSimpleName();
    int mStartMode;       // indicates how to behave if the service is killed
    IBinder mBinder;      // interface for clients that bind
    boolean mAllowRebind; // indicates whether onRebind should be used

    public Event_Service() {

    }

    @Override
    public void onCreate() {

        // Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+".."+ b);
        // https://developer.android.com/reference/android/app/ActivityManager.RecentTaskInfo.html

        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]);

        new Thread(new Runnable() {

            @Override
            public void run() {

                Globals g = Globals.getInstance();
                DataInputStream in = null;
                byte[] timeval = new byte[16];
                short type, code;
                int value;

                try {
                    in = new DataInputStream( new FileInputStream("/dev/input/event0"));
                    while (g.isRunning) {

                        // sleep(g.mServicesSleepTime);
                        // SCREEN_OFF_TIMEOUT   SOUND_EFFECTS_ENABLED  VIBRATE_ON VIBRATE_WHEN_RINGING
                        in.readFully(timeval);
                        type = in.readShort();
                        code = in.readShort();
                        value = in.readInt();
                        // sizeof(struct timeval) = 16
                        Log.d(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--EVENT"+type+","+code+","+value);
                        int curBrightnessValue = android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS,-1);
                        g.metaContext.mDeviceInfo.mCreateTime= Calendar.getInstance();
                        g.metaContext.mDeviceInfo.mData="LCD Brightness:"+curBrightnessValue;

                        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"--LCD=="+curBrightnessValue);
         /* String myExec = "sh settings get system screen_brightnes";
                        StringBuilder result=new StringBuilder();
                        final StringBuilder append = result.append("....");
                        Process process;
                        try {
                            process = Runtime.getRuntime().exec("am start -a android.intent.action.MAIN -n com.android.settings/.Settings");
                            process = Runtime.getRuntime().exec("getprop  ro.sf.lcd_density");
                            process = Runtime.getRuntime().exec("cat /sys/class/leds/lcd-backlight/brightness");
                            process = Runtime.getRuntime().exec("cat /sys/class/power_supply/battery/current_now");
                            process.waitFor();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                            String s = reader.readLine();
                            long currentTime = System.currentTimeMillis();
                        }
                        catch(Exception e) {
                            e.printStackTrace();
                        }  */

                    }

                } catch (FileNotFoundException e) {

                    Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]+"FileNotFoundException");
                }

                catch (IOException e) {
                    e.printStackTrace();
                    Log.i(TAG, "IOException" + Thread.currentThread().getStackTrace()[2]+e);

                }   catch (Exception e) {

                    Log.i(TAG, "Exception" + Thread.currentThread().getStackTrace()[2]+e);

                }





            }
        }).start();



        return Service.START_STICKY;
        //return mStartMode;




    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
        // A client is binding to the service with bindService()
        return mBinder;

    }


    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return mAllowRebind;
    }
    @Override
    public void onRebind(Intent intent) {
        // A client is binding to the service with bindService(),
        // after onUnbind() has already been called
    }


    @Override
    public void onDestroy() {


        Log.i(TAG, "" + Thread.currentThread().getStackTrace()[2]);
    }





}

